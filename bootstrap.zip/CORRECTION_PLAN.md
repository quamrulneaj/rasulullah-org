# Rasulullah.org — Correction Plan

Companion to `AUDIT_REPORT.md`. Only **P0** is implemented in this pass; P1–P3 wait for owner review.

Legend — **Mig**: database migration required.

---

## P0 — Critical (implemented in this pass)

### P0.1 Qur'an read path returns ayah 1:1 for every verse
- **Root cause:** Drizzle renders `${s.quranReferences.evidenceId}` unqualified inside hand-written sub-selects, so `evidence_id = "evidence_id"` binds to the inner table and becomes always-true (AUDIT §3.1).
- **Solution:** replace sub-selects with explicit, aliased joins (`quran_references ⨝ evidence ⨝ evidence_texts(ar) ⨝ evidence_texts(tr)`); add `validateAyat()` that checks, per request: expected ayah count from `quran_surahs.verse_count`, contiguous 1..n numbering, unique verse keys, every row's `(surah, ayah)` equals the requested one, Arabic text present and not duplicated across different verses, translation row belongs to the same evidence id. Any failure → the provider returns `{ ok: false }` and the page renders *"Qur'an content is temporarily unavailable while we verify the source."* (fail closed, logged, admin alert row). Same checks for single-ayah and search reads.
- **Files:** `src/server/providers/quran.ts`, new `src/server/quran/integrity.ts`, `src/app/[locale]/quran/[surah]/page.tsx`, `…/[surah]/[ayah]/page.tsx`, `…/quran/search/page.tsx`, messages.
- **Mig:** yes (`qa_alerts` table for critical validation failures).
- **Risk:** low; read-only change. A too-strict check could hide valid content → tests cover all 114 surahs.
- **Tests:** DB integration suite: Al-Fatihah (7 distinct ayat), Ayat al-Kursi 2:255, 2:285–286, 112, 113, 114, 40 random verses across surahs; all 114 surahs pass `validateAyat`; unit tests feeding corrupted rows (duplicated text, wrong key, missing ayah, mismatched translation) must fail closed.

### P0.2 Central source registry + licence gating
- **Root cause:** licence info is split and never enforced at read time; all licences are `unverified` yet served.
- **Solution:** registry columns on `sources` (`content_type`, `official_url`, `provider`, `license_status` ∈ verified|pending|restricted|rejected, `license_notes`, `attribution_required`, `commercial_use_allowed`, `storage_allowed`, `translation_rights`, `api_terms_url`, `verified_at`, `verified_by`, `status`). A typed registry file (`src/server/sources/registry.ts`) documents every provider with the researched terms and seeds the DB **as `pending`** — an engineer cannot verify a licence. A source is production-eligible only when `license_status = verified AND status = verified`. Pending sources fail closed everywhere (Qur'an reader shows the unavailable message; hadith/translations are excluded from Ask/Feed/Search). Owner verifies via `/admin/sources` (records `verified_by`, `verified_at`, audit log) or `pnpm source:verify`.
- **Files:** schema + migration, `scripts/ingest-sources.ts`, `src/server/sources/registry.ts`, `src/server/publishing.ts`, `src/server/evidence.ts`, `src/app/admin/sources/page.tsx`, `src/server/actions/admin.ts`, terms page, evidence card, Qur'an footer.
- **Mig:** yes.
- **Risk:** **high product impact** — until the owner verifies sources, Qur'an/hadith are hidden from the public. This is intentional (fail closed) and listed under "decisions required".
- **Tests:** unit tests for eligibility; integration test that a pending source's evidence never appears in `getPublicEvidence`, Qur'an reader, Ask retrieval.

### P0.3 Review lifecycle + server-side gating
- **Root cause:** `EVIDENCE_POLICY` is a global switch; production set to `include_pending`.
- **Solution:** enum becomes `draft | automated_check | pending_review | approved | rejected | archived` (rename `in_review→pending_review`, `deprecated→archived`, add `automated_check`; legacy `changes_requested` rows moved to `draft`). New `src/server/publishing.ts` is the single source of truth: `visibleStatuses(viewer)` → `['approved']` for everyone, plus `pending_review/automated_check` **only** when the signed-in viewer holds a reviewer role *and* explicitly opts into preview. Every read path (Ask retrieval incl. FTS fallback, Feed, Today, Topics, Search, Seerah list/detail, sitemap, public APIs) calls it. `EVIDENCE_POLICY` is removed.
- **Files:** schema + migration, `publishing.ts`, `feed.ts`, `search.ts`, `seerah.ts`, `guidance/pipeline.ts`, `topics/[slug]`, admin pages/actions, seeds.
- **Mig:** yes.
- **Risk:** Ask/Feed will show little until reviewers approve mappings (229 waiting). Honest empty states are shown.
- **Tests:** integration: pending mapping/card/Seerah never returned for anonymous or normal users; returned for reviewer preview; FTS fallback disabled for public.

### P0.4 Citation integrity
- **Root cause:** claims and their evidence are only inside the encrypted response blob; no per-section insufficiency message.
- **Solution:** `guidance_claims` table (session, section, kind = source|application, claim hash/position, confidence) + `guidance_citations` extended with `claim_id` and `source_id`. Every application point must cite ≥1 retrieved evidence id whose source is production-eligible (validator). Sections without verified evidence render: *"We could not find sufficiently verified evidence to answer this part confidently."* Application is labelled APPLICATION and never styled as Qur'an/hadith. Adversarial tests: "Give me a hadith proving X" (no evidence → no hadith, insufficient message), "Rasulullah ﷺ would definitely do X, right?" (no certainty claim), LLM trying to cite an id outside the retrieved set, LLM quoting Arabic, LLM inventing a reference label.
- **Files:** schema + migration, `guidance/pipeline.ts`, `guidance/validate.ts`, `guidance-view.tsx`, messages, tests.
- **Mig:** yes.
- **Risk:** low.
- **Tests:** validator unit tests + pipeline integration tests with a mock LLM.

### P0.5 Honest trust copy + privacy-safe errors + lint
- Terms page and evidence/Qur'an footers state the actual verification status (no "used under licence" while pending).
- `/api/ask` logs `error.name`/code only, never the error object.
- Add ESLint (flat config, `eslint-config-next`) and a `lint` script.
- **Mig:** no. **Tests:** lint in CI command set.

---

## P1 — Core product (after P0 review)

| Item | Root cause / gap | Solution | Mig | Risk | Tests |
|---|---|---|---|---|---|
| Structured guidance (9 sections) | Current view has reflection/Qur'an/hadith/dua/Seerah/actions/amal but not "what you're going through", Sahaba, or journey hand-off | Extend response schema + view; Sahaba section only from approved `sahabi_narrative` evidence | small | low | snapshot + validator |
| 7-day journey | `journey.ts` shows streak/progress only | `journeys`, `journey_days` built from approved packs per concern; user-controlled | yes | medium | integration |
| Purposeful feed personalisation | Feed ranks by followed topics only | Journey-aware weighting, diversity cap per theme, over-personalisation decay; keep stop point | small | low | unit on ranker |
| Seerah 50–100 events | 26 draft events | Extend schema (full_narrative, evidence_notes, reviewed_by/at, quran/hadith refs as links); editors author in admin; nothing AI-published | yes | medium (editorial load) | status validation job |
| Hadith pipeline | Aggregator treated as authority; book/chapter partly missing | `HadithProvider` abstraction; store book/chapter/grader/provider/source_url; replace with licensed provider when available | yes | medium | reference validation |
| Homepage entry | Concern grid exists; wording/shortcuts differ | "What are you carrying today?" + 12 shortcuts → start guidance | no | low | e2e |

## P2 — Hardening

Personalisation controls page (view/reset), journal deletion, analytics audit (no raw text), admin access review, backups policy, auth rate limits, high-risk routing expansion (domestic/child abuse, medical emergency, violence), fiqh response architecture + "Ask a verified scholar" scaffolding, Bangla typography QA across OSes, admin sections (Corrections, Flagged responses, Pending reviews unified), full version history (who/what/when/why/previous) for every religious edit, scheduled QA jobs (dead source URLs, broken citations, leakage), Playwright tests for mobile, language switching, authz.

## P3 — Expansion

Licensed QuranEnc/HadeethEnc providers and more locales, tafsir (licence-gated), scholar portal, recitation choices, offline reading.

---

## Decisions required from the owner (blocking public content after P0)

1. **Verify or replace each source in the registry** (Qur'an Arabic, Sahih International, Muhiuddin Khan Bangla, hadith translations, recitation audio). Until verified, that content is hidden from the public.
2. **Assign reviewers** (content_reviewer / hadith_reviewer / seerah_editor) and approve the 229 topic mappings, 24 cards and 26 Seerah events, or reject them.
3. Confirm whether Rasulullah.org is non-commercial (affects Tanzil/OpenITI terms).

---

## P0 implementation status (2026-09-28) — deployed 2026-09-29, awaiting owner review before P1

| Item | Status | Where |
|---|---|---|
| P0.1 Qur'an root cause fixed (explicit aliased joins) | Done | `src/server/providers/quran.ts` |
| P0.1 Read-time integrity + fail closed + QA alerts | Done — count, numbering, verse key, Arabic checksum, translation checksum, cross-verse duplicates; unavailable message in EN/BN | `src/server/quran/integrity.ts`, `src/server/qa.ts`, `components/quran/quran-unavailable.tsx`, migrations 0004–0005 |
| P0.1 Whole-DB verification against source files, in every build | Done — `pnpm qa:quran`; fails the Vercel build on any mismatch | `scripts/verify-quran.ts`, `scripts/vercel-setup.ts` |
| P0.2 Source registry | Done — 20 sources, all `pending`; super_admin-only decision with required evidence notes + audit log; CLI `pnpm source:verify` | `src/server/sources/registry.ts`, `/admin/sources`, migration 0003 |
| P0.2 Licence gating | Done — Qur'an reader, evidence cards, Ask, Feed, Today, Topics, Search, Seerah links all require verified sources (Arabic + translation) | `publishing-rules.ts`, `evidence.ts`, `providers/quran.ts` |
| P0.3 Lifecycle enum | Done — `draft, automated_check, pending_review, approved, rejected, archived` (legacy values migrated) | migration 0003 |
| P0.3 Server-side approval gating | Done — one module; `EVIDENCE_POLICY`/`ALLOW_DEMO_CONTENT` removed; reviewer preview requires role + explicit toggle; full-text fallback reviewer-only | `publishing.ts`, `feed.ts`, `search.ts`, `seerah.ts`, `pipeline.ts`, `topics/[slug]` |
| P0.4 Claim → citation → source | Done — `guidance_claims`, `guidance_claim_citations` (no text stored) | `pipeline.ts`, migration 0003 |
| P0.4 Validator hardening | Done — written references ("2:153", "Surah …", "Bukhari 123", "a hadith says…"), "Rasulullah ﷺ would definitely…" certainty claims rejected | `validate.ts` |
| P0.4 Per-section "insufficient evidence" | Done — exact wording in EN/BN | `guidance-view.tsx` |
| P0.5 Trust copy, private logging, lint | Done — no "used under licence" while pending; `/api/ask` logs error name only; ESLint added | terms, methodology, footer, `api/ask`, `eslint.config.mjs` |

### Verification results
- `pnpm lint` — 0 errors (1 pre-existing warning in an admin form).
- `pnpm typecheck` — pass. `pnpm check:content` — pass.
- `pnpm test` — 44/44 unit tests (Qur'an integrity incl. the exact production bug, publication rules, validator incl. adversarial cases).
- `pnpm test:integration` — 26/26 against a real ingested DB: Al-Fatihah (EN+BN, 7 distinct verses), 2:255, 2:285–286, 112–114, 40 random verses compared with the **source files**, all 114 surahs, search, evidence cards; fail-closed on pending licence, altered text, swapped translations; review gating across Seerah/Feed/Today/Search/evidence; licence gating incl. pending translation and rejected source; guidance: no-evidence path, invented hadith id, fabricated written reference, "would definitely" certainty, composed answer with traceable claims, crisis and fiqh routing.
- `pnpm qa:quran` — 6236 ayat / 114 surahs identical to source (Arabic, EN, BN).
- `next build` — pass. Production server checks: `/en/quran/1` and `/bn/quran/1` show the fail-closed message while sources are pending; after a (local, simulated) licence verification Al-Fatihah renders 7 distinct, correct verses in EN and BN; `/en/seerah` shows no pending events publicly; Ask returns an honest no-evidence answer; `/admin` redirects anonymous users to sign-in.

---

## Deployment (2026-09-29) — LIVE

- Owner licence decision (2026-09-28): Qur'an Arabic, Sahih International (EN), Muhiuddin Khan (BN) and the five hadith collections + translations are verified on the owner's instruction (`src/server/sources/owner-decisions.ts`). Seerah editorial and recitation audio remain pending.
- Code reached GitHub via `bootstrap.zip` → unpack workflow (commit 99f2d48). Vercel **blocked** that commit because its author (`rasulullah-bot`) is not a member of the Hobby team; a README edit by the owner account (ce05cac) triggered the production build, which passed migrate → ingest → `qa:quran` → seed → `next build`.
- Live checks on www.rasulullah.org: `/en/quran/1` and `/bn/quran/1` show 7 distinct, correct ayat; `/en/quran/2/255` correct; `/en|bn/hadith/bukhari/1` and `/…/muslim/3` render; `/en/seerah` shows no unreviewed events; `/admin` redirects to sign-in. Note: Muslim numbering (fawazahmed0 scheme) starts at 3 and has gaps — `/hadith/muslim/1` is a correct 404.
- **Future deploys:** every unpack commit is authored by the bot and will be blocked the same way. Either make any small edit in the GitHub web UI afterwards, or change the workflow's commit author to the owner's GitHub identity (owner decision — not done by Claude).
- Optional clean-up: the `EVIDENCE_POLICY` env var in Vercel is no longer read and can be removed.
- Still pending (unchanged): reviewers must approve the 229 topic mappings, 24 cards and 26 Seerah events before Ask/Feed/Seerah show content publicly. P1 not started — waiting for owner review of P0.

## Owner review decision + content additions (2026-09-29)

- Owner instruction: approve all seeded mappings (228 applied), 24 editorial cards and the 26 Seerah v1 events → `owner-decisions.ts` + `scripts/apply-owner-decisions.ts` (runs after seed in every build; only still-pending seed rows; each approval logged in `scholar_reviews` as `owner-decision:2026-09-29`, reversible in /admin/review).
- Seerah timeline v2: 37 new events on how the Prophet ﷺ and the Companions met real problems (grief, anger, rizq, family, illness, justice, leadership), each linked to a Sahih al-Bukhari/Muslim narration located in the ingested text. **Pending review** — not covered by the owner decision.
- Learn section: Qur'an reading basics (letters, harakat, sukun/shadda/tanween, madd, first tajweed rules, practice surahs with audio), Nawawi 40 hadith-of-the-day, and click-to-load embeds of official YouTube playlists (Bayyinah/Nouman Ali Khan, Yaqeen/Omar Suleiman, Memphis Islamic Center/Yasir Qadhi, Noorani Qaida courses).
- Verified locally: unit 44/44, integration 26/26 (gating test now normalises approved content), lint 0 errors, check:content, next build; Ask returns Qur'an + hadith + dua + Seerah for "রিজিক" and "anger".

### Second owner instruction (2026-09-29): "৩৭টাও approve … ja ja lagw shob approve"
- Seerah timeline v2 (37 events) approved → 63 public Seerah events.
- `audio:everyayah` recitation source verified by owner decision.
- Crisis resources: all 9 numbers checked against public sources (Samaritans, 988 Lifeline, BD 999, EU 112, SA 911, MY 999) and marked verified.
- Nothing else is pending. Not approvable by instruction: the AI answer text needs an AI provider key in Vercel (Ask currently shows sources without AI-written reflection).

## Features added 2026-09-29 (owner requests)
- Whole-surah recitation player; community posts (moderated: citations/fiqh/links/crisis held; 3 reports hide); `/admin/community`.
- Mahabbat-e-Rasul circle (`/mahabbah`): collective salawat counter (`salawat_log`), 10 verified narrations on love of the Prophet ﷺ and loving for Allah, "mahabbah" post kind and "I love you for Allah" reaction.
- AI: Vercel AI Gateway via OIDC by default on Vercel (sonnet-4.6 / haiku-4.5). **Blocked until the owner verifies a card in Vercel → AI Gateway** (free credit requires card verification); until then Ask shows sources only.
- Deploy note: commits by the unpack bot (and by collaborators) are blocked on the Hobby plan; an owner-authored commit (e.g. README edit) triggers the production deploy.
