/**
 * Bangla display labels for Seerah metadata (dates, places, people, bibliography). The stored values are
 * English; on the Bangla site every visible label is shown in Bangla. Unknown strings fall back to the
 * stored value so nothing disappears.
 */
const DATES: Record<string, string> = {
  "c. 570 CE (Year of the Elephant)": "আনুমানিক ৫৭০ খ্রিস্টাব্দ (হস্তীর বছর)",
  "Childhood": "শৈশবকাল",
  "Before prophethood (c. 605 CE)": "নবুয়তের পূর্বে (আনুমানিক ৬০৫ খ্রিস্টাব্দ)",
  "c. 610 CE": "আনুমানিক ৬১০ খ্রিস্টাব্দ",
  "After a pause in revelation": "ওহীর বিরতির পর",
  "Early Makkan period": "মক্কী যুগের শুরুর দিকে",
  "Makkan period": "মক্কী যুগ",
  "c. 615 CE onwards": "আনুমানিক ৬১৫ খ্রিস্টাব্দ থেকে",
  "c. 619 CE (the Year of Sorrow)": "আনুমানিক ৬১৯ খ্রিস্টাব্দ (শোকের বছর)",
  "c. 619 CE": "আনুমানিক ৬১৯ খ্রিস্টাব্দ",
  "Before the Hijrah": "হিজরতের আগে",
  "c. 621–622 CE": "আনুমানিক ৬২১–৬২২ খ্রিস্টাব্দ",
  "622 CE (1 AH)": "৬২২ খ্রিস্টাব্দ (১ হিজরি)",
  "1 AH": "১ হিজরি",
  "Ramadan, 2 AH": "রমজান, ২ হিজরি",
  "Shawwal, 3 AH": "শাওয়াল, ৩ হিজরি",
  "5 AH": "৫ হিজরি",
  "Dhul-Qa'dah, 6 AH": "জিলকদ, ৬ হিজরি",
  "7 AH": "৭ হিজরি",
  "Ramadan, 8 AH": "রমজান, ৮ হিজরি",
  "Shawwal, 8 AH": "শাওয়াল, ৮ হিজরি",
  "Rajab, 9 AH": "রজব, ৯ হিজরি",
  "Dhul-Hijjah, 10 AH": "জিলহজ, ১০ হিজরি",
  "Rabi' al-Awwal, 11 AH": "রবিউল আউয়াল, ১১ হিজরি",
  "10 AH": "১০ হিজরি",
  "Madinan period": "মাদানি যুগ",
  "c. 4 AH": "আনুমানিক ৪ হিজরি",
  "Ten years in Madinah": "মদিনার দশ বছর",
  "c. 6 AH": "আনুমানিক ৬ হিজরি",
  "8 AH, before the conquest": "৮ হিজরি, মক্কা বিজয়ের আগে",
  "c. 5–6 AH": "আনুমানিক ৫–৬ হিজরি",
  "11 AH": "১১ হিজরি",
  "After Uhud (3 AH)": "উহুদের পর (৩ হিজরি)",
  "During the truce (6–8 AH)": "সন্ধির সময়কালে (৬–৮ হিজরি)",
  "8 AH": "৮ হিজরি",
  "c. 9–10 AH": "আনুমানিক ৯–১০ হিজরি",
  "c. 2 AH": "আনুমানিক ২ হিজরি",
  "After the conquest of Makkah": "মক্কা বিজয়ের পর",
};

const PLACES: Record<string, string> = {
  "Makkah": "মক্কা",
  "Among Banu Sa'd (desert)": "বনু সা'দ গোত্রে (মরুভূমিতে)",
  "Cave of Hira, near Makkah": "হেরা গুহা, মক্কার কাছে",
  "Mount Safa, Makkah": "সাফা পাহাড়, মক্কা",
  "Mina / Makkah": "মিনা / মক্কা",
  "The Ka'bah, Makkah": "কাবা, মক্কা",
  "Abyssinia (Ethiopia)": "হাবশা (ইথিওপিয়া)",
  "Qarn ath-Tha'alib, on the return from Ta'if (per Seerah historians)": "কারনুস সাআলিব, তায়েফ থেকে ফেরার পথে (সীরাতবিদদের মতে)",
  "Makkah to Jerusalem and the heavens": "মক্কা থেকে বায়তুল মাকদিস ও ঊর্ধ্বাকাশ",
  "Al-'Aqabah, Mina": "আকাবা, মিনা",
  "Makkah → Cave of Thawr → Madinah": "মক্কা → সাওর গুহা → মদিনা",
  "Madinah": "মদিনা",
  "Badr": "বদর",
  "Mount Uhud, near Madinah": "উহুদ পাহাড়, মদিনার কাছে",
  "Al-Hudaybiyyah": "হুদায়বিয়া",
  "Khaybar": "খায়বার",
  "Hunayn": "হুনাইন",
  "Tabuk / Madinah": "তাবুক / মদিনা",
  "Makkah, Arafah and Mina": "মক্কা, আরাফাহ ও মিনা",
  "The Prophet's Mosque": "মসজিদে নববী",
  "The Prophet's Mosque (Suffa)": "মসজিদে নববী (সুফফা)",
  "Market of Madinah": "মদিনার বাজার",
  "His home in Madinah": "মদিনায় তাঁর ঘর",
  "Madinah / Makkah": "মদিনা / মক্কা",
  "Madinah → Yemen": "মদিনা → ইয়েমেন",
};

const PEOPLE: Record<string, string> = {
  "Jibril (AS)": "জিবরীল (আঃ)", "Al-'Abbas (RA)": "আব্বাস (রাঃ)", "Khadijah (RA)": "খাদিজা (রাঃ)", "Waraqah ibn Nawfal": "ওয়ারাকা ইবনে নওফল",
  "Abu Lahab": "আবু লাহাব", "Fatimah (RA)": "ফাতিমা (রাঃ)", "'Uqba ibn Abi Mu'ayt": "উকবা ইবনে আবি মুআইত", "Abu Jahl": "আবু জাহল",
  "Ja'far ibn Abi Talib (RA)": "জাফর ইবনে আবি তালিব (রাঃ)", "An-Najashi (the Negus)": "নাজাশি (হাবশার বাদশাহ)", "Abu Talib": "আবু তালিব",
  "Aisha (RA)": "আয়েশা (রাঃ)", "Musa (AS)": "মূসা (আঃ)", "'Ubada ibn as-Samit (RA)": "উবাদা ইবনে সামিত (রাঃ)", "Ka'b ibn Malik (RA)": "কা'ব ইবনে মালিক (রাঃ)",
  "Abu Bakr (RA)": "আবু বকর (রাঃ)", "Asma' bint Abi Bakr (RA)": "আসমা বিনতে আবি বকর (রাঃ)", "Suraqa ibn Malik": "সুরাকা ইবনে মালিক",
  "'Ammar ibn Yasir (RA)": "আম্মার ইবনে ইয়াসির (রাঃ)", "Banu an-Najjar": "বনু নাজ্জার", "'Abdur-Rahman ibn 'Awf (RA)": "আব্দুর রহমান ইবনে আউফ (রাঃ)",
  "Sa'd ibn ar-Rabi' (RA)": "সা'দ ইবনে রাবি (রাঃ)", "'Abdullah ibn Jubayr (RA)": "আব্দুল্লাহ ইবনে জুবায়ের (রাঃ)", "Mus'ab ibn 'Umayr (RA)": "মুসআব ইবনে উমায়ের (রাঃ)",
  "Jabir ibn 'Abdullah (RA)": "জাবির ইবনে আব্দুল্লাহ (রাঃ)", "'Umar ibn al-Khattab (RA)": "উমর ইবনুল খাত্তাব (রাঃ)", "'Ali ibn Abi Talib (RA)": "আলী ইবনে আবি তালিব (রাঃ)",
  "Abu Sufyan": "আবু সুফিয়ান", "Abu Sufyan ibn al-Harith (RA)": "আবু সুফিয়ান ইবনুল হারিস (রাঃ)", "Al-Bara' ibn 'Azib (RA)": "বারা ইবনে আযিব (রাঃ)",
  "'Umar (RA)": "উমর (রাঃ)", "Ibrahim (son of the Prophet ﷺ)": "ইবরাহিম (নবী ﷺ-এর পুত্র)", "Anas (RA)": "আনাস (রাঃ)", "Umm Sulaym (RA)": "উম্মে সুলাইম (রাঃ)",
  "Abu Talha (RA)": "আবু তালহা (রাঃ)", "Umm Salama (RA)": "উম্মে সালামা (রাঃ)", "Abu Salama (RA)": "আবু সালামা (রাঃ)", "Abu Huraira (RA)": "আবু হুরায়রা (রাঃ)",
  "Anas ibn Malik (RA)": "আনাস ইবনে মালিক (রাঃ)", "Thumama ibn Uthal (RA)": "সুমামা ইবনে উসাল (রাঃ)", "Hatib ibn Abi Balta'a (RA)": "হাতিব ইবনে আবি বালতাআ (রাঃ)",
  "'Ali (RA)": "আলী (রাঃ)", "Mistah (RA)": "মিসতাহ (রাঃ)", "An Ansari couple": "এক আনসারি দম্পতি", "People of the Suffa": "আসহাবে সুফফা",
  "Hakim ibn Hizam (RA)": "হাকিম ইবনে হিযাম (রাঃ)", "Abu Sa'id al-Khudri (RA)": "আবু সাঈদ খুদরি (রাঃ)", "Some of the Ansar": "কয়েকজন আনসার",
  "Poor Muhajirun": "দরিদ্র মুহাজিরগণ", "Fatima (RA)": "ফাতিমা (রাঃ)", "Ibn 'Abbas (RA)": "ইবনে আব্বাস (রাঃ)", "Sa'd ibn Abi Waqqas (RA)": "সা'দ ইবনে আবি ওয়াক্কাস (রাঃ)",
  "Salman al-Farisi (RA)": "সালমান ফারসি (রাঃ)", "Abu ad-Darda' (RA)": "আবুদ দারদা (রাঃ)", "Umm ad-Darda' (RA)": "উম্মুদ দারদা (রাঃ)",
  "Al-Hasan ibn 'Ali (RA)": "হাসান ইবনে আলী (রাঃ)", "Al-Aqra' ibn Habis": "আকরা ইবনে হাবিস", "Abu Qatada (RA)": "আবু কাতাদা (রাঃ)",
  "Sa'd ibn 'Ubada (RA)": "সা'দ ইবনে উবাদা (রাঃ)", "Ibn 'Umar (RA)": "ইবনে উমর (রাঃ)", "Usama ibn Zayd (RA)": "উসামা ইবনে যায়েদ (রাঃ)",
  "Abu Dharr (RA)": "আবু যর (রাঃ)", "Mu'adh ibn Jabal (RA)": "মুআজ ইবনে জাবাল (রাঃ)",
  "Bilal (RA)": "বিলাল (রাঃ)", "Anas ibn an-Nadr (RA)": "আনাস ইবনে নাদর (রাঃ)", "Wahshi": "ওয়াহশি", "Hamza (RA)": "হামযা (রাঃ)",
  "Sa'd ibn Mu'adh (RA)": "সা'দ ইবনে মুআজ (রাঃ)", "Abu Jandal (RA)": "আবু জান্দাল (রাঃ)", "Suhayl ibn 'Amr": "সুহাইল ইবনে আমর", "'Abdullah ibn Mas'ud (RA)": "আব্দুল্লাহ ইবনে মাসউদ (রাঃ)",
};

const DIGITS = "০১২৩৪৫৬৭৮৯";
export const bnDigits = (s: string) => s.replace(/\d/g, (d) => DIGITS[Number(d)]!);

/** Bibliography lines: "Sahih al-Bukhari 1303 (Anas)" → "সহিহ বুখারি ১৩০৩ (আনাস)". */
function bib(s: string) {
  let out = s
    .replace("Ibn Hisham, al-Sirah al-Nabawiyyah (further reading)", "ইবনে হিশাম, আস-সীরাতুন নাবাবিয়্যাহ (আরও পড়ার জন্য)")
    .replace("Ibn Kathir, al-Sirah al-Nabawiyyah (further reading)", "ইবনে কাসীর, আস-সীরাতুন নাবাবিয়্যাহ (আরও পড়ার জন্য)")
    .replace("Safiur Rahman Mubarakpuri, Ar-Raheeq al-Makhtum (further reading)", "সফিউর রহমান মোবারকপুরী, আর-রাহীকুল মাখতূম (আরও পড়ার জন্য)")
    .replace(/Sahih al-Bukhari/g, "সহিহ বুখারি").replace(/Sahih Muslim/g, "সহিহ মুসলিম").replace(/Qur'an/g, "কুরআন");
  out = out.replace(/\(([^)]+)\)/g, (m, inner: string) => {
    const names = inner.split(/,\s*/).map((n) => PEOPLE[`${n} (RA)`]?.replace(" (রাঃ)", "") ?? NAME_ONLY[n] ?? n);
    return `(${names.join(", ")})`;
  });
  return bnDigits(out);
}
const NAME_ONLY: Record<string, string> = { Anas: "আনাস", Aisha: "আয়েশা", Jabir: "জাবির", "Abu Huraira": "আবু হুরায়রা", "Anas ibn Malik": "আনাস ইবনে মালিক", "Abu Qatada": "আবু কাতাদা", "Ibn 'Umar": "ইবনে উমর", "Ibn 'Abbas": "ইবনে আব্বাস", "'Ali": "আলী", "Abu Juhayfa": "আবু জুহাইফা", "Asma'": "আসমা", "Abu Dharr": "আবু যর", "Umm Salama": "উম্মে সালামা", "Abu Sa'id al-Khudri": "আবু সাঈদ খুদরি", "Al-Bara'": "বারা", "'Abdullah ibn 'Umar": "আব্দুল্লাহ ইবনে উমর", "Usama ibn Zayd": "উসামা ইবনে যায়েদ", "'Abdullah ibn Mas'ud": "আব্দুল্লাহ ইবনে মাসউদ", "Abu Qatada'": "আবু কাতাদা", "'Abdur-Rahman ibn 'Awf": "আব্দুর রহমান ইবনে আউফ", "Sa'd ibn Abi Waqqas": "সা'দ ইবনে আবি ওয়াক্কাস", "Hakim ibn Hizam": "হাকিম ইবনে হিযাম", "Al-Miswar ibn Makhrama and Marwan": "মিসওয়ার ইবনে মাখরামা ও মারওয়ান", "Wahshi": "ওয়াহশি", "via Ja'far ibn 'Amr": "জাফর ইবনে আমরের সূত্রে", "Ibn Abbas": "ইবনে আব্বাস", "Ibn Mas'ud": "ইবনে মাসউদ", "al-Musayyab": "মুসাইয়্যিব", "Malik ibn Sa'sa'a": "মালিক ইবনে সা'সাআ", "Suraqa": "সুরাকা", "Abu Bakr": "আবু বকর", "Abu Sa'id": "আবু সাঈদ", "al-Bara'": "বারা", "Sahl ibn Sa'd": "সাহল ইবনে সা'দ" };

export function seerahLabels<T extends { date?: string | null; location?: string | null; people?: string[] }>(e: T, locale: string): T {
  if (locale !== "bn") return e;
  return {
    ...e,
    date: e.date ? DATES[e.date] ?? bnDigits(e.date) : e.date,
    location: e.location ? PLACES[e.location] ?? e.location : e.location,
    people: e.people?.map((p) => PEOPLE[p] ?? p),
  };
}
export const bibLabel = (citation: string, locale: string) => (locale === "bn" ? bib(citation) : citation);
