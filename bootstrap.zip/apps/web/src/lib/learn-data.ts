/**
 * Learn section data. NOT religious source text:
 *  - The Arabic alphabet and vowel marks are built from Unicode code points (teaching the script, not quoting
 *    the Qur'an), so no Arabic literal appears in source (scripts/check-content.ts).
 *  - Practice verses are read live from the verified Qur'an store via links to the reader.
 *  - Video courses are EMBEDS of the publishers' own official YouTube playlists (the video stays on YouTube,
 *    with the channel's name and link). Nothing is downloaded or re-hosted.
 */
const c = (...cps: number[]) => String.fromCodePoint(...cps);

export const FATHA = 0x064e, KASRA = 0x0650, DAMMA = 0x064f, SUKUN = 0x0652, SHADDA = 0x0651;
export const TANWEEN_F = 0x064b, TANWEEN_K = 0x064d, TANWEEN_D = 0x064c;
const ALIF = 0x0627, WAW = 0x0648, YA = 0x064a, BA = 0x0628;

export type Letter = { ch: string; name: string; bn: string; sound: string; spoken: string };
/** Arabic names of the letters (for the pronunciation button), as code points. */
const SPOKEN: number[][] = [
  [0x623, 0x644, 0x641],
  [0x628, 0x627, 0x621],
  [0x62a, 0x627, 0x621],
  [0x62b, 0x627, 0x621],
  [0x62c, 0x64a, 0x645],
  [0x62d, 0x627, 0x621],
  [0x62e, 0x627, 0x621],
  [0x62f, 0x627, 0x644],
  [0x630, 0x627, 0x644],
  [0x631, 0x627, 0x621],
  [0x632, 0x627, 0x64a],
  [0x633, 0x64a, 0x646],
  [0x634, 0x64a, 0x646],
  [0x635, 0x627, 0x62f],
  [0x636, 0x627, 0x62f],
  [0x637, 0x627, 0x621],
  [0x638, 0x627, 0x621],
  [0x639, 0x64a, 0x646],
  [0x63a, 0x64a, 0x646],
  [0x641, 0x627, 0x621],
  [0x642, 0x627, 0x641],
  [0x643, 0x627, 0x641],
  [0x644, 0x627, 0x645],
  [0x645, 0x64a, 0x645],
  [0x646, 0x648, 0x646],
  [0x647, 0x627, 0x621],
  [0x648, 0x627, 0x648],
  [0x64a, 0x627, 0x621],
];
export const ALPHABET: Letter[] = ([
  [0x0627, "Alif", "আলিফ", "a"], [0x0628, "Ba", "বা", "b"], [0x062a, "Ta", "তা", "t"], [0x062b, "Tha", "ছা", "th (thin)"],
  [0x062c, "Jim", "জীম", "j"], [0x062d, "Ha", "হা (গলার মাঝখান)", "ḥ"], [0x062e, "Kha", "খা", "kh"], [0x062f, "Dal", "দাল", "d"],
  [0x0630, "Dhal", "যাল", "dh (this)"], [0x0631, "Ra", "রা", "r"], [0x0632, "Zay", "যা", "z"], [0x0633, "Sin", "সীন", "s"],
  [0x0634, "Shin", "শীন", "sh"], [0x0635, "Sad", "সোয়াদ", "ṣ (heavy s)"], [0x0636, "Dad", "দোয়াদ", "ḍ (heavy d)"], [0x0637, "Ta", "ত্বোয়া", "ṭ (heavy t)"],
  [0x0638, "Za", "যোয়া", "ẓ (heavy dh)"], [0x0639, "'Ayn", "আইন", "ʿ"], [0x063a, "Ghayn", "গাইন", "gh"], [0x0641, "Fa", "ফা", "f"],
  [0x0642, "Qaf", "ক্বাফ", "q (deep k)"], [0x0643, "Kaf", "কাফ", "k"], [0x0644, "Lam", "লাম", "l"], [0x0645, "Mim", "মীম", "m"],
  [0x0646, "Nun", "নূন", "n"], [0x0647, "Ha", "হা (হালকা)", "h"], [0x0648, "Waw", "ওয়াও", "w / ū"], [0x064a, "Ya", "ইয়া", "y / ī"],
] as const).map(([cp, name, bn, sound], i) => ({ ch: c(cp), name, bn, sound, spoken: c(...SPOKEN[i]!) }));

export type Example = { ch: string; say: string };
export const HARAKAT: Example[] = [
  { ch: c(BA, FATHA), say: "ba" }, { ch: c(BA, KASRA), say: "bi" }, { ch: c(BA, DAMMA), say: "bu" },
];
export const SUKUN_SHADDA: Example[] = [
  { ch: c(ALIF, FATHA, BA, SUKUN), say: "ab" }, { ch: c(BA, SHADDA, FATHA), say: "bba" },
  { ch: c(BA, TANWEEN_F, ALIF), say: "ban" }, { ch: c(BA, TANWEEN_K), say: "bin" }, { ch: c(BA, TANWEEN_D), say: "bun" },
];
export const MADD: Example[] = [
  { ch: c(BA, FATHA, ALIF), say: "bā" }, { ch: c(BA, KASRA, YA), say: "bī" }, { ch: c(BA, DAMMA, WAW), say: "bū" },
];

type T = { en: string; bn: string };
export type Lesson = { id: string; title: T; body: T; examples?: Example[]; letters?: boolean };
export const QURAN_BASICS: Lesson[] = [
  { id: "letters", letters: true,
    title: { en: "1 · The 28 letters", bn: "১ · ২৮টি হরফ" },
    body: { en: "Arabic is read right to left. Learn each letter's name and sound; practise a few each day.", bn: "আরবি ডান থেকে বামে পড়া হয়। প্রতিটি হরফের নাম ও উচ্চারণ শিখুন; প্রতিদিন কয়েকটি করে অনুশীলন করুন।" } },
  { id: "harakat", examples: HARAKAT,
    title: { en: "2 · Short vowels (harakat)", bn: "২ · হরকত (যবর, যের, পেশ)" },
    body: { en: "Fatha (a stroke above) gives 'a', kasra (a stroke below) gives 'i', damma (a small waw above) gives 'u'.", bn: "যবর (উপরে দাগ) = 'আ', যের (নিচে দাগ) = 'ই', পেশ (উপরে ছোট ওয়াও) = 'উ'।" } },
  { id: "sukun", examples: SUKUN_SHADDA,
    title: { en: "3 · Sukun, shadda and tanween", bn: "৩ · জযম, তাশদীদ ও তানভীন" },
    body: { en: "Sukun (a small circle) means the letter has no vowel. Shadda (a small 'w' shape) doubles the letter. Tanween (doubled vowel marks) adds an 'n' sound at the end.", bn: "জযম (ছোট গোল চিহ্ন) মানে হরফে কোনো স্বর নেই। তাশদীদ হরফকে দ্বিগুণ করে। তানভীন (দুটো হরকত) শেষে 'ন' ধ্বনি যোগ করে।" } },
  { id: "madd", examples: MADD,
    title: { en: "4 · Long vowels (madd)", bn: "৪ · মাদ (দীর্ঘ স্বর)" },
    body: { en: "Alif after fatha, ya after kasra and waw after damma stretch the vowel for two counts.", bn: "যবরের পর আলিফ, যেরের পর ইয়া, পেশের পর ওয়াও — স্বরকে দুই হরকত পরিমাণ টেনে পড়ায়।" } },
  { id: "tajweed",
    title: { en: "5 · First tajweed rules", bn: "৫ · তাজবীদের প্রথম নিয়ম" },
    body: {
      en: "Noon sakin and tanween have four rules: izhar (read clearly before throat letters), idgham (merge into the next letter), iqlab (turns into a 'm' sound before ba) and ikhfa (a hidden, nasal sound before the remaining letters). Learn them by listening to a qualified teacher.",
      bn: "নূন সাকিন ও তানভীনের চারটি নিয়ম: ইযহার (হলকি হরফের আগে স্পষ্ট), ইদগাম (পরের হরফে মিলিয়ে), ইকলাব (বা-এর আগে 'ম' ধ্বনি) ও ইখফা (বাকি হরফের আগে নাকে গোপন করে)। যোগ্য শিক্ষকের কাছে শুনে শুনে শিখুন।",
    } },
];
/** Short surahs to practise with, read from the verified Qur'an reader (with recitation audio). */
export const PRACTICE_SURAHS = [1, 112, 113, 114, 103, 108, 110, 97];

export type Playlist = { id: string; title: string; channel: string; channelUrl: string; lang: "en" | "bn" | "ur"; group: "reading" | "quran" | "tafsir" | "seerah" | "latest" };
export const PLAYLISTS: Playlist[] = [
  { id: "PLsubX4v29PRQYoxpWo-3I8x99DLOOpaGT", title: "নুরানী কায়দা শিক্ষা", channel: "সহিহ দাওয়াহ", channelUrl: "https://www.youtube.com/playlist?list=PLsubX4v29PRQYoxpWo-3I8x99DLOOpaGT", lang: "bn", group: "reading" },
  { id: "PLSCByKt3vw-Y0mkz6GOJvn4Qrq8KCGhr0", title: "Learn How To Read The Quran", channel: "Roots Of Knowledge", channelUrl: "https://www.youtube.com/@RootsOfKnowledge", lang: "en", group: "reading" },
  { id: "PLutdSTmJ7bAIRI04Wy6GOlyA-r2C7xODT", title: "Surah Ar-Rahman: A Deeper Look", channel: "Nouman Ali Khan · Bayyinah", channelUrl: "https://www.youtube.com/@bayyinah", lang: "en", group: "tafsir" },
  { id: "PLutdSTmJ7bAK9Wwx1Rp7aiM4Exy_hyXqc", title: "A Deeper Look: Surah Al-Muzzammil", channel: "Nouman Ali Khan · Bayyinah", channelUrl: "https://www.youtube.com/@bayyinah", lang: "en", group: "tafsir" },
  { id: "PLutdSTmJ7bAJtUlGavSxX2XTgC7ZWg5kr", title: "Surah Al-Muddaththir: A Deeper Look", channel: "Nouman Ali Khan · Bayyinah", channelUrl: "https://www.youtube.com/@bayyinah", lang: "en", group: "tafsir" },
  { id: "PLutdSTmJ7bAJGw4eW56Qe46F257dL_cG9", title: "Striking Examples in the Quran 2.0", channel: "Nouman Ali Khan · Bayyinah", channelUrl: "https://www.youtube.com/@bayyinah", lang: "en", group: "quran" },
  { id: "PLutdSTmJ7bAKNmsOFX33NrJSYUadwwufd", title: "What Everyone Should Know About Abraham", channel: "Nouman Ali Khan · Bayyinah", channelUrl: "https://www.youtube.com/@bayyinah", lang: "en", group: "quran" },
  { id: "PLutdSTmJ7bAJGbvHkdXHwCs6vCS1OZ-M2", title: "Quran For Hearts & Minds: The Power of Maqamat", channel: "Nouman Ali Khan · Bayyinah", channelUrl: "https://www.youtube.com/@bayyinah", lang: "en", group: "quran" },
  { id: "PLutdSTmJ7bAJoDx2NYzI_uhnbtddK7Gg0", title: "Story Night: Pharaoh Shall Drown", channel: "Nouman Ali Khan · Bayyinah", channelUrl: "https://www.youtube.com/@bayyinah", lang: "en", group: "tafsir" },
  { id: "PLQ02IYL5pmhHvZ02LKQVeey8H-2XBKMGb", title: "Meeting Muhammad ﷺ", channel: "Dr. Omar Suleiman · Yaqeen Institute", channelUrl: "https://www.youtube.com/@yaqeeninstituteofficial", lang: "en", group: "seerah" },
  { id: "PLC89682017B43845D", title: "Seerah of the Prophet ﷺ (Dr. Yasir Qadhi)", channel: "Memphis Islamic Center", channelUrl: "https://www.youtube.com/playlist?list=PLC89682017B43845D", lang: "en", group: "seerah" },
  // Channel "uploads" playlists (UU + channel id), channel ids read from the official channel pages on 2026-09-29.
  { id: "UU3vHW2h22WE-pNi5WJtRIjg", title: "Latest from Yaqeen Institute", channel: "Yaqeen Institute", channelUrl: "https://www.youtube.com/@yaqeeninstituteofficial", lang: "en", group: "latest" },
  { id: "UURtiU-lpcBSi-ipFKyfIkug", title: "Latest from Nouman Ali Khan", channel: "Nouman Ali Khan · Bayyinah", channelUrl: "https://www.youtube.com/@bayyinah", lang: "en", group: "latest" },
  { id: "UUNB_OaI4524fASt8h0IL8dw", title: "Latest from Mufti Menk", channel: "Mufti Menk", channelUrl: "https://www.youtube.com/@muftimenkofficial", lang: "en", group: "latest" },
];

/** Imam an-Nawawi's Forty Hadith — the dataset numbers them 1–42. */
export const NAWAWI_COUNT = 42;
export function nawawiOfTheDay(d = new Date()) {
  const start = Date.UTC(d.getUTCFullYear(), 0, 0);
  const day = Math.floor((d.getTime() - start) / 86_400_000);
  return (day % NAWAWI_COUNT) + 1;
}
