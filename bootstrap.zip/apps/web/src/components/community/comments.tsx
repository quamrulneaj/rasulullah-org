"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { addComment, deleteOwnComment, reportComment } from "@/server/actions/community";
import { COMMENT_MAX } from "@/server/community-rules";

type C = { id: string; body: string; author: string; mine: boolean; held: boolean };

export function Comments({ postId, comments, signedIn }: { postId: string; comments: C[]; signedIn: boolean }) {
  const t = useTranslations("community");
  const router = useRouter();
  const [open, setOpen] = useState(comments.length > 0 && comments.length <= 3);
  const [body, setBody] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const visible = open ? comments : comments.slice(-2);

  return (
    <div className="mt-3 border-t border-line pt-3">
      {comments.length > 2 && !open ? (
        <button type="button" onClick={() => setOpen(true)} className="mb-2 text-xs text-fg-muted hover:text-fg">{t("comments.showAll", { n: comments.length })}</button>
      ) : null}
      <ul className="flex flex-col gap-2">
        {visible.map((c) => (
          <li key={c.id} className="rounded-xl bg-surface-muted px-3 py-2 text-sm">
            <span className="font-semibold text-fg">{c.author}</span>
            {c.held ? <span className="ms-2 text-xs text-gold-700">{t("awaitingReview")}</span> : null}
            <p className="whitespace-pre-wrap break-words text-fg">{c.body}</p>
            <div className="mt-1 flex gap-3 text-xs text-fg-muted">
              {c.mine ? (
                <button type="button" onClick={() => start(async () => { await deleteOwnComment(c.id); router.refresh(); })} className="hover:text-terracotta-600">{t("delete")}</button>
              ) : signedIn ? (
                <button type="button" onClick={() => start(async () => { await reportComment(c.id); setMsg(t("reported")); })} className="hover:text-fg">{t("report")}</button>
              ) : null}
            </div>
          </li>
        ))}
      </ul>
      {signedIn ? (
        <form
          className="mt-2 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            start(async () => {
              const r = await addComment(postId, body);
              if (!r.ok) return setMsg(t(`errors.${r.error}`));
              setBody("");
              setMsg(r.status === "held" ? (r.crisis ? t("heldCrisis") : t("comments.held")) : null);
              setOpen(true);
              router.refresh();
            });
          }}
        >
          <label htmlFor={`c-${postId}`} className="sr-only">{t("comments.placeholder")}</label>
          <input id={`c-${postId}`} value={body} onChange={(e) => setBody(e.target.value)} maxLength={COMMENT_MAX} placeholder={t("comments.placeholder")} className="min-w-0 flex-1 rounded-full border border-line bg-bg px-3 py-1.5 text-sm text-fg outline-none focus:border-gold-500" />
          <button type="submit" disabled={pending || body.trim().length < 2} className="rounded-full bg-green-900 px-4 py-1.5 text-sm text-ivory-50 disabled:opacity-50">{t("comments.send")}</button>
        </form>
      ) : null}
      {msg ? <p role="status" className="mt-2 text-xs text-fg-muted">{msg}</p> : null}
    </div>
  );
}
