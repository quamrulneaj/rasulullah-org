import { getTranslations } from "next-intl/server";
import { PLAYLISTS, type Playlist } from "@/lib/learn-data";
import { PlaylistEmbed } from "./playlist-embed";

/** A row of video courses for one group, reused on the Seerah and Qur'an pages. */
export async function PlaylistSection({ groups, locale, title }: { groups: Playlist["group"][]; locale: string; title: string }) {
  const t = await getTranslations("learn");
  const items = PLAYLISTS.filter((p) => groups.includes(p.group));
  if (!items.length) return null;
  return (
    <section className="mt-16">
      <h2 className="text-2xl font-semibold text-fg">{title}</h2>
      <p className="mt-2 max-w-2xl text-sm text-fg-muted">{t("videos.lead")}</p>
      <div className="mt-5 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {items.map((p) => (
          <PlaylistEmbed key={p.id} id={p.id} title={p.title} channel={p.channel} channelUrl={p.channelUrl} playLabel={t("videos.play")} openLabel={t("videos.open")} captionLang={locale === "bn" && p.lang !== "bn" ? "bn" : undefined} />
        ))}
      </div>
    </section>
  );
}
