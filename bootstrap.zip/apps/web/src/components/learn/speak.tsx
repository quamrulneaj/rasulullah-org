"use client";

import { useState } from "react";
import { Volume2 } from "lucide-react";

/**
 * Pronounces Arabic with the device's own Arabic text-to-speech voice (no audio files, nothing sent anywhere).
 * Computer voices are an aid only — exact pronunciation (makhraj) is learned from a teacher.
 */
export function Speak({ text, label, noVoice }: { text: string; label: string; noVoice: string }) {
  const [warn, setWarn] = useState(false);
  return (
    <span className="inline-flex flex-col items-center">
      <button
        type="button"
        aria-label={label}
        onClick={() => {
          const synth = typeof window !== "undefined" ? window.speechSynthesis : undefined;
          if (!synth) return setWarn(true);
          const voices = synth.getVoices();
          const voice = voices.find((v) => v.lang.toLowerCase().startsWith("ar"));
          if (!voice && voices.length) return setWarn(true);
          synth.cancel();
          const u = new SpeechSynthesisUtterance(text);
          u.lang = voice?.lang ?? "ar-SA";
          if (voice) u.voice = voice;
          u.rate = 0.7;
          synth.speak(u);
        }}
        className="inline-flex h-7 w-7 items-center justify-center rounded-full text-fg-muted hover:bg-surface-muted hover:text-fg"
      >
        <Volume2 className="h-4 w-4" aria-hidden />
      </button>
      {warn ? <span className="mt-1 max-w-28 text-center text-[10px] leading-tight text-gold-700">{noVoice}</span> : null}
    </span>
  );
}
