import "server-only";
import { and, desc, eq, inArray, lt, or, sql } from "drizzle-orm";
import { db, schema as s } from "./db";
import { REACTIONS, type Reaction } from "./community-rules";

export type CommunityPost = {
  id: string; kind: string; body: string; status: string; createdAt: Date; author: string; mine: boolean;
  reactions: Record<Reaction, number>; reacted: string[];
  comments: { id: string; body: string; author: string; mine: boolean; held: boolean; createdAt: Date }[];
};

/** Public feed: published posts, plus the viewer's own held posts (so they know it is waiting for review). */
export async function listPosts(opts: { userId: string | null; before?: Date; limit?: number; kind?: string }): Promise<CommunityPost[]> {
  const limit = opts.limit ?? 20;
  const base = opts.userId
    ? or(eq(s.communityPosts.status, "published"), and(eq(s.communityPosts.userId, opts.userId), eq(s.communityPosts.status, "held")))
    : eq(s.communityPosts.status, "published");
  const visible = opts.kind ? and(base, eq(s.communityPosts.kind, opts.kind)) : base;
  const rows = await db
    .select({ id: s.communityPosts.id, kind: s.communityPosts.kind, body: s.communityPosts.body, status: s.communityPosts.status, createdAt: s.communityPosts.createdAt, userId: s.communityPosts.userId, name: s.user.name })
    .from(s.communityPosts)
    .innerJoin(s.user, eq(s.user.id, s.communityPosts.userId))
    .where(opts.before ? and(visible, lt(s.communityPosts.createdAt, opts.before)) : visible)
    .orderBy(desc(s.communityPosts.createdAt))
    .limit(limit);
  const ids = rows.map((r) => r.id);
  const counts = ids.length
    ? await db.select({ postId: s.communityReactions.postId, kind: s.communityReactions.kind, n: sql<number>`count(*)::int` }).from(s.communityReactions).where(inArray(s.communityReactions.postId, ids)).groupBy(s.communityReactions.postId, s.communityReactions.kind)
    : [];
  const mine = ids.length && opts.userId
    ? await db.select({ postId: s.communityReactions.postId, kind: s.communityReactions.kind }).from(s.communityReactions).where(and(inArray(s.communityReactions.postId, ids), eq(s.communityReactions.userId, opts.userId)))
    : [];
  const comments = ids.length
    ? await db.select({ id: s.communityComments.id, postId: s.communityComments.postId, body: s.communityComments.body, status: s.communityComments.status, userId: s.communityComments.userId, createdAt: s.communityComments.createdAt, name: s.user.name })
        .from(s.communityComments).innerJoin(s.user, eq(s.user.id, s.communityComments.userId))
        .where(and(inArray(s.communityComments.postId, ids), opts.userId
          ? or(eq(s.communityComments.status, "published"), and(eq(s.communityComments.status, "held"), eq(s.communityComments.userId, opts.userId)))
          : eq(s.communityComments.status, "published")))
        .orderBy(s.communityComments.createdAt)
    : [];
  return rows.map((r) => ({
    id: r.id, kind: r.kind, body: r.body, status: r.status, createdAt: r.createdAt,
    author: firstName(r.name), mine: r.userId === opts.userId,
    reactions: Object.fromEntries(REACTIONS.map((k) => [k, counts.find((c) => c.postId === r.id && c.kind === k)?.n ?? 0])) as Record<Reaction, number>,
    reacted: mine.filter((m) => m.postId === r.id).map((m) => m.kind),
    comments: comments.filter((c) => c.postId === r.id).map((c) => ({ id: c.id, body: c.body, author: firstName(c.name), mine: c.userId === opts.userId, held: c.status === "held", createdAt: c.createdAt })),
  }));
}

/** Only a first name is shown publicly (privacy by default). */
function firstName(name: string) {
  return (name.trim().split(/\s+/)[0] ?? "").slice(0, 30) || "—";
}

export async function salawatStats(userId: string | null) {
  const day = new Date().toISOString().slice(0, 10);
  const [t] = await db.select({ today: sql<number>`coalesce(sum(${s.salawatLog.count}) filter (where ${s.salawatLog.day} = ${day}), 0)::int`, total: sql<number>`coalesce(sum(${s.salawatLog.count}), 0)::int`, people: sql<number>`count(distinct ${s.salawatLog.userId}) filter (where ${s.salawatLog.day} = ${day})::int` }).from(s.salawatLog);
  const [mine] = userId ? await db.select({ n: s.salawatLog.count }).from(s.salawatLog).where(and(eq(s.salawatLog.userId, userId), eq(s.salawatLog.day, day))) : [];
  return { today: t?.today ?? 0, total: t?.total ?? 0, people: t?.people ?? 0, mine: mine?.n ?? 0 };
}
