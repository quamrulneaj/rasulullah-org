import "server-only";
import { surahName } from "@/lib/surah-names-bn";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db, schema as s } from "./db";
import { demoVisible, sourceEligible, statusVisible, type Viewer } from "./publishing-rules";
import { checkAyah, sha256 } from "./quran/integrity";
import { raiseQaAlert } from "./qa";

/** Collection names shown on the Bangla site. Chapter (book) names exist only in English in the dataset, so they are hidden there. */
const COLLECTIONS_BN: Record<string, string> = { bukhari: "সহিহ বুখারি", muslim: "সহিহ মুসলিম", nawawi: "ইমাম নববীর চল্লিশ হাদিস", tirmidhi: "জামে তিরমিযি", abudawud: "সুনানে আবু দাউদ" };


export type Locale = "en" | "bn";

export type Grade = { grade: string; grader: string };
export type EvidenceView = {
  id: string;
  kind: "quran_ayah" | "hadith" | "seerah_event" | "sahabi_narrative" | "scholar_excerpt" | "dua" | "editorial_note";
  ref: string;
  trust: "A" | "B" | "C" | "D" | "E";
  isDemo: boolean;
  arabic: string | null;
  translation: string | null;
  translationLocale: Locale | null;
  translationSource: string | null;
  attribution: string | null;
  /** approved = public; preview = shown only to a reviewer in preview mode (pending evidence or unverified source). */
  publication: "approved" | "preview";
  quran?: { surah: number; ayah: number; surahName: string; surahNameLocal: string };
  hadith?: { collection: string; collectionName: string; collectionNameBn: string | null; number: string; arabicNumber: string | null; bookName: string | null; grades: Grade[] };
};

/**
 * Evidence text is ALWAYS loaded from the database by id — never from model output.
 *
 * Publication gate (server-side, every caller): an item is returned only when
 *   - its review status is visible to the viewer (public: `approved` only),
 *   - it is not demo content (unless reviewer preview),
 *   - its source AND the source of the translation shown are production-eligible (licence verified),
 *   - Qur'an items pass the read-time integrity check (verse identity + checksum).
 * Anything else is silently omitted; callers must treat missing ids as "not available".
 */
export async function getEvidence(ids: string[], locale: Locale, viewer: Viewer): Promise<Map<string, EvidenceView>> {
  const out = new Map<string, EvidenceView>();
  if (!ids.length) return out;
  const base = await db
    .select({
      id: s.evidence.id, kind: s.evidence.kind, ref: s.evidence.canonicalRef, trust: s.evidence.trustLevel, isDemo: s.evidence.isDemo, reviewStatus: s.evidence.reviewStatus,
      sourceName: s.sources.name, sourceNotes: s.sources.notes, srcLicense: s.sources.licenseStatus, srcStatus: s.sources.status, attribution: s.licenses.attributionText,
    })
    .from(s.evidence)
    .innerJoin(s.sources, eq(s.sources.id, s.evidence.sourceId))
    .leftJoin(s.licenses, eq(s.licenses.id, s.sources.licenseId))
    .where(inArray(s.evidence.id, [...new Set(ids)]));
  const texts = await db
    .select({ evidenceId: s.evidenceTexts.evidenceId, locale: s.evidenceTexts.locale, role: s.evidenceTexts.role, text: s.evidenceTexts.text, sha: s.evidenceTexts.textSha256, srcName: s.sources.name, srcLicense: s.sources.licenseStatus, srcStatus: s.sources.status })
    .from(s.evidenceTexts)
    .leftJoin(s.sources, eq(s.sources.id, s.evidenceTexts.translationSourceId))
    .where(and(inArray(s.evidenceTexts.evidenceId, ids), inArray(s.evidenceTexts.locale, ["ar", locale, "en"])));
  const qrefs = await db
    .select({ evidenceId: s.quranReferences.evidenceId, surah: s.quranReferences.surah, ayah: s.quranReferences.ayah, sha: s.quranReferences.arabicSha256, translit: s.quranSurahs.transliteration, nameEn: s.quranSurahs.nameEn, nameBn: s.quranSurahs.nameBn })
    .from(s.quranReferences)
    .innerJoin(s.quranSurahs, eq(s.quranSurahs.number, s.quranReferences.surah))
    .where(inArray(s.quranReferences.evidenceId, ids));
  const hrefs = await db.select().from(s.hadithReferences).where(inArray(s.hadithReferences.evidenceId, ids));
  const grades = await db.select().from(s.hadithGradings).where(inArray(s.hadithGradings.evidenceId, ids));

  const eligible = (x: { srcLicense: string | null; srcStatus: string | null }) => sourceEligible(viewer, { licenseStatus: x.srcLicense ?? "", status: x.srcStatus ?? "" });
  const strictlyVerified = (x: { srcLicense: string | null; srcStatus: string | null }) => x.srcLicense === "verified" && x.srcStatus === "verified";

  for (const b of base) {
    if (!statusVisible(viewer, b.reviewStatus) || !demoVisible(viewer, b.isDemo) || !eligible(b)) continue;
    const t = texts.filter((x) => x.evidenceId === b.id);
    const ar = t.find((x) => x.role === "original_arabic" && eligible(x));
    const local = t.find((x) => x.role === "translation" && x.locale === locale && eligible(x)) ?? t.find((x) => x.role === "translation" && x.locale === "en" && eligible(x));
    const q = qrefs.find((x) => x.evidenceId === b.id);
    const h = hrefs.find((x) => x.evidenceId === b.id);
    // Qur'an and hadith are only ever shown with their original text and an eligible translation.
    if ((q || h) && (!ar || !local)) continue;
    if (q) {
      const errors = checkAyah({ evidenceId: b.id, surah: q.surah, ayah: q.ayah, expectedSha256: q.sha, arabic: ar!.text, arabicEvidenceId: ar!.evidenceId, translation: local!.text, translationEvidenceId: local!.evidenceId, translationSha256: local!.sha });
      if (errors.length) { await raiseQaAlert("quran_integrity", `evidence:${b.ref}`, { errors }); continue; }
    } else if (h) {
      // Hadith texts carry the same ingest checksum; an altered or swapped text is withheld.
      const bad = [ar, local].filter((x) => x && (!x.sha || sha256(x.text) !== x.sha));
      if (bad.length) { await raiseQaAlert("hadith_integrity", `evidence:${b.ref}`, { roles: bad.map((x) => `${x!.role}:${x!.locale}`) }); continue; }
    }
    const approved = b.reviewStatus === "approved" && !b.isDemo && strictlyVerified(b) && (!ar || strictlyVerified(ar)) && (!local || strictlyVerified(local));
    const v: EvidenceView = {
      id: b.id, kind: b.kind, ref: b.ref, trust: b.trust, isDemo: b.isDemo, arabic: ar?.text ?? null,
      translation: local?.text ?? null, translationLocale: (local?.locale as Locale) ?? null, translationSource: local?.srcName ?? null,
      attribution: b.attribution, publication: approved ? "approved" : "preview",
    };
    if (q) v.quran = { surah: q.surah, ayah: q.ayah, surahName: surahName(q.surah, q.translit, locale), surahNameLocal: locale === "bn" ? q.nameBn : q.nameEn };
    if (h) v.hadith = {
      collection: h.collection, collectionName: locale === "bn" ? COLLECTIONS_BN[h.collection] ?? b.sourceName : b.sourceName, collectionNameBn: b.sourceNotes, number: h.hadithNumber, arabicNumber: h.arabicNumber, bookName: locale === "bn" ? null : h.bookName,
      grades: grades.filter((g) => g.evidenceId === b.id).map((g) => ({ grade: g.grade, grader: g.grader })),
    };
    out.set(b.id, v);
  }
  return out;
}

export async function evidenceIdsByRefs(refs: string[]) {
  if (!refs.length) return new Map<string, string>();
  const rows = await db.select({ id: s.evidence.id, ref: s.evidence.canonicalRef }).from(s.evidence).where(inArray(s.evidence.canonicalRef, refs));
  return new Map(rows.map((r) => [r.ref, r.id]));
}

/**
 * Hadith eligibility for high-confidence guidance:
 *  - collections without per-hadith gradings in our data (Sahihayn, Nawawi 40) → eligible via source trust;
 *  - graded collections → at least one Sahih/Hasan and no Da'if/Mawdu' grading.
 */
export function hadithEligible(v: EvidenceView) {
  if (!v.hadith) return true;
  const g = v.hadith.grades.map((x) => x.grade.toLowerCase());
  if (!g.length) return ["bukhari", "muslim", "nawawi"].includes(v.hadith.collection);
  const weak = g.some((x) => /da.?if|daif|weak|mawdu|fabricat|munkar/.test(x));
  const ok = g.some((x) => /sahih|hasan/.test(x));
  return ok && !weak;
}

export async function surahVerseCount(n: number) {
  const [r] = await db.select({ c: s.quranSurahs.verseCount }).from(s.quranSurahs).where(eq(s.quranSurahs.number, n));
  return r?.c ?? 0;
}

export const sqlNow = sql`now()`;
