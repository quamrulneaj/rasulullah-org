import "server-only";
import { and, asc, eq, inArray, or } from "drizzle-orm";
import { db, schema as s } from "./db";
import { visibleStatuses, type Viewer } from "./publishing-rules";
import type { Locale } from "./evidence";
import { bibLabel, seerahLabels } from "@/lib/seerah-labels";

/**
 * Which Seerah events a viewer may see: approved, non-demo events for everyone; pending ones and
 * demo rows only for a reviewer in preview mode. Enforced server-side for every read.
 */
export function seerahVisible(viewer: Viewer) {
  const statuses = visibleStatuses(viewer);
  const real = and(inArray(s.seerahEvents.reviewStatus, statuses), eq(s.seerahEvents.isDemo, false));
  return viewer.preview ? or(real, eq(s.seerahEvents.isDemo, true)) : real;
}

export async function listSeerah(locale: Locale, viewer: Viewer) {
  const periods = await db.select().from(s.seerahPeriods).orderBy(asc(s.seerahPeriods.order));
  const events = await db
    .select({ id: s.seerahEvents.id, slug: s.seerahEvents.slug, periodId: s.seerahEvents.periodId, order: s.seerahEvents.order, date: s.seerahEvents.approximateDate, certainty: s.seerahEvents.dateCertainty, location: s.seerahEvents.location, people: s.seerahEvents.people, themes: s.seerahEvents.themes, isDemo: s.seerahEvents.isDemo, reviewStatus: s.seerahEvents.reviewStatus, title: s.seerahEventTranslations.title, summary: s.seerahEventTranslations.summary, lessons: s.seerahEventTranslations.lessons })
    .from(s.seerahEvents)
    .innerJoin(s.seerahEventTranslations, and(eq(s.seerahEventTranslations.eventId, s.seerahEvents.id), eq(s.seerahEventTranslations.locale, locale)))
    .where(seerahVisible(viewer))
    .orderBy(asc(s.seerahEvents.order));
  return { periods, events: events.map((e) => seerahLabels(e, locale)) };
}

export async function getSeerahEvent(slug: string, locale: Locale, viewer: Viewer) {
  const [e] = await db
    .select({ id: s.seerahEvents.id, slug: s.seerahEvents.slug, periodId: s.seerahEvents.periodId, date: s.seerahEvents.approximateDate, certainty: s.seerahEvents.dateCertainty, location: s.seerahEvents.location, people: s.seerahEvents.people, themes: s.seerahEvents.themes, isDemo: s.seerahEvents.isDemo, reviewStatus: s.seerahEvents.reviewStatus, updatedAt: s.seerahEvents.updatedAt, version: s.seerahEvents.version, title: s.seerahEventTranslations.title, summary: s.seerahEventTranslations.summary, narrative: s.seerahEventTranslations.narrative, lessons: s.seerahEventTranslations.lessons })
    .from(s.seerahEvents)
    .innerJoin(s.seerahEventTranslations, and(eq(s.seerahEventTranslations.eventId, s.seerahEvents.id), eq(s.seerahEventTranslations.locale, locale)))
    .where(and(eq(s.seerahEvents.slug, slug), seerahVisible(viewer)));
  if (!e) return null;
  const [period] = await db.select().from(s.seerahPeriods).where(eq(s.seerahPeriods.id, e.periodId));
  const links = await db.select().from(s.seerahEventLinks).where(eq(s.seerahEventLinks.eventId, e.id));
  const bib = await db.select().from(s.bibliographyEntries).where(eq(s.bibliographyEntries.eventId, e.id));
  return { ...seerahLabels(e, locale), period, links, bib: bib.map((b) => ({ ...b, citation: bibLabel(b.citation, locale) })) };
}
