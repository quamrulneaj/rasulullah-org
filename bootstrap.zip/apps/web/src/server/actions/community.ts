"use server";

import { and, eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db, schema as s } from "../db";
import { getSession, requireCapability } from "../session";
import { rateLimit } from "../rate-limit";
import { logAudit } from "../audit";
import { AUTO_HIDE_REPORTS, POST_KINDS, REACTIONS, reviewComment, reviewPost, type Reaction } from "../community-rules";

type Err = "auth" | "invalid" | "rate_limited" | "too_short" | "too_long";
const revalidate = () => revalidatePath("/[locale]/community", "page");

export async function createPost(input: { kind: string; body: string; locale: string }): Promise<{ ok: true; status: "published" | "held"; crisis: boolean } | { ok: false; error: Err }> {
  const session = await getSession();
  if (!session) return { ok: false, error: "auth" };
  const p = z.object({ kind: z.enum(POST_KINDS), body: z.string(), locale: z.enum(["en", "bn"]) }).safeParse(input);
  if (!p.success) return { ok: false, error: "invalid" };
  const d = reviewPost(p.data.body);
  if (!d.ok) return { ok: false, error: d.error };
  if (!(await rateLimit(`post:${session.user.id}`, 5, 3600))) return { ok: false, error: "rate_limited" };
  await db.insert(s.communityPosts).values({ userId: session.user.id, kind: p.data.kind, body: p.data.body.trim(), locale: p.data.locale, status: d.status, heldReason: d.reasons.join(",") || null });
  revalidate();
  return { ok: true, status: d.status, crisis: d.crisis };
}

export async function toggleReaction(postId: string, kind: Reaction): Promise<{ ok: boolean; on?: boolean; error?: Err }> {
  const session = await getSession();
  if (!session) return { ok: false, error: "auth" };
  if (!z.string().uuid().safeParse(postId).success || !(REACTIONS as readonly string[]).includes(kind)) return { ok: false, error: "invalid" };
  const where = and(eq(s.communityReactions.postId, postId), eq(s.communityReactions.userId, session.user.id), eq(s.communityReactions.kind, kind));
  const [cur] = await db.select().from(s.communityReactions).where(where);
  if (cur) { await db.delete(s.communityReactions).where(where); return { ok: true, on: false }; }
  const [post] = await db.select({ status: s.communityPosts.status }).from(s.communityPosts).where(eq(s.communityPosts.id, postId));
  if (post?.status !== "published") return { ok: false, error: "invalid" };
  await db.insert(s.communityReactions).values({ postId, userId: session.user.id, kind }).onConflictDoNothing();
  return { ok: true, on: true };
}

export async function reportPost(postId: string, reason: string): Promise<{ ok: boolean; error?: Err }> {
  const session = await getSession();
  if (!session) return { ok: false, error: "auth" };
  const p = z.object({ postId: z.string().uuid(), reason: z.enum(["wrong_religious_info", "inappropriate", "spam", "other"]) }).safeParse({ postId, reason });
  if (!p.success) return { ok: false, error: "invalid" };
  if (!(await rateLimit(`report:${session.user.id}`, 20, 3600))) return { ok: false, error: "rate_limited" };
  const [dup] = await db.select({ id: s.reports.id }).from(s.reports).where(and(eq(s.reports.targetType, "community_post"), eq(s.reports.targetId, postId), eq(s.reports.reporterId, session.user.id)));
  if (dup) return { ok: true };
  await db.insert(s.reports).values({ reporterId: session.user.id, targetType: "community_post", targetId: postId, reason: p.data.reason });
  // Enough independent reports hide a post until a moderator looks at it.
  await db.update(s.communityPosts).set({ reportCount: sql`${s.communityPosts.reportCount} + 1`, status: sql`CASE WHEN ${s.communityPosts.reportCount} + 1 >= ${AUTO_HIDE_REPORTS} AND ${s.communityPosts.status} = 'published' THEN 'hidden'::community_post_status ELSE ${s.communityPosts.status} END` }).where(eq(s.communityPosts.id, postId));
  revalidate();
  return { ok: true };
}

export async function deleteOwnPost(postId: string): Promise<{ ok: boolean }> {
  const session = await getSession();
  if (!session || !z.string().uuid().safeParse(postId).success) return { ok: false };
  await db.delete(s.communityPosts).where(and(eq(s.communityPosts.id, postId), eq(s.communityPosts.userId, session.user.id)));
  revalidate();
  return { ok: true };
}

export async function moderatePost(postId: string, status: "published" | "hidden" | "removed"): Promise<{ ok: boolean }> {
  const { session } = await requireCapability("handleReports");
  await db.update(s.communityPosts).set({ status, moderatedBy: session.user.id, updatedAt: new Date() }).where(eq(s.communityPosts.id, postId));
  await logAudit(session.user.id, `community.${status}`, "community_post", postId);
  revalidate();
  revalidatePath("/admin/community");
  return { ok: true };
}

/** Record salawat sent on the Prophet ﷺ today (adds to today's count). */
export async function addSalawat(n: number): Promise<{ ok: boolean; today?: number; error?: Err }> {
  const session = await getSession();
  if (!session) return { ok: false, error: "auth" };
  if (!Number.isInteger(n) || n < 1 || n > 10000) return { ok: false, error: "invalid" };
  if (!(await rateLimit(`salawat:${session.user.id}`, 120, 3600))) return { ok: false, error: "rate_limited" };
  const day = new Date().toISOString().slice(0, 10);
  const [row] = await db.insert(s.salawatLog).values({ userId: session.user.id, day, count: n })
    .onConflictDoUpdate({ target: [s.salawatLog.userId, s.salawatLog.day], set: { count: sql`least(${s.salawatLog.count} + ${n}, 100000)`, updatedAt: new Date() } })
    .returning({ count: s.salawatLog.count });
  revalidatePath("/[locale]/mahabbah", "page");
  return { ok: true, today: row?.count };
}

export async function addComment(postId: string, body: string): Promise<{ ok: true; status: "published" | "held"; crisis: boolean } | { ok: false; error: Err }> {
  const session = await getSession();
  if (!session) return { ok: false, error: "auth" };
  if (!z.string().uuid().safeParse(postId).success || typeof body !== "string") return { ok: false, error: "invalid" };
  const d = reviewComment(body);
  if (!d.ok) return { ok: false, error: d.error };
  const [post] = await db.select({ status: s.communityPosts.status }).from(s.communityPosts).where(eq(s.communityPosts.id, postId));
  if (post?.status !== "published") return { ok: false, error: "invalid" };
  if (!(await rateLimit(`comment:${session.user.id}`, 30, 3600))) return { ok: false, error: "rate_limited" };
  await db.insert(s.communityComments).values({ postId, userId: session.user.id, body: body.trim(), status: d.status, heldReason: d.reasons.join(",") || null });
  revalidate();
  return { ok: true, status: d.status, crisis: d.crisis };
}

export async function deleteOwnComment(id: string): Promise<{ ok: boolean }> {
  const session = await getSession();
  if (!session || !z.string().uuid().safeParse(id).success) return { ok: false };
  await db.delete(s.communityComments).where(and(eq(s.communityComments.id, id), eq(s.communityComments.userId, session.user.id)));
  revalidate();
  return { ok: true };
}

export async function reportComment(id: string): Promise<{ ok: boolean; error?: Err }> {
  const session = await getSession();
  if (!session) return { ok: false, error: "auth" };
  if (!z.string().uuid().safeParse(id).success) return { ok: false, error: "invalid" };
  if (!(await rateLimit(`report:${session.user.id}`, 20, 3600))) return { ok: false, error: "rate_limited" };
  const [dup] = await db.select({ id: s.reports.id }).from(s.reports).where(and(eq(s.reports.targetType, "community_comment"), eq(s.reports.targetId, id), eq(s.reports.reporterId, session.user.id)));
  if (dup) return { ok: true };
  await db.insert(s.reports).values({ reporterId: session.user.id, targetType: "community_comment", targetId: id, reason: "inappropriate" });
  await db.update(s.communityComments).set({ reportCount: sql`${s.communityComments.reportCount} + 1`, status: sql`CASE WHEN ${s.communityComments.reportCount} + 1 >= ${AUTO_HIDE_REPORTS} AND ${s.communityComments.status} = 'published' THEN 'hidden'::community_post_status ELSE ${s.communityComments.status} END` }).where(eq(s.communityComments.id, id));
  revalidate();
  return { ok: true };
}

export async function moderateComment(id: string, status: "published" | "hidden" | "removed"): Promise<{ ok: boolean }> {
  const { session } = await requireCapability("handleReports");
  await db.update(s.communityComments).set({ status }).where(eq(s.communityComments.id, id));
  await logAudit(session.user.id, `community_comment.${status}`, "community_comment", id);
  revalidate();
  revalidatePath("/admin/community");
  return { ok: true };
}
