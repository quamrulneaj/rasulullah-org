/**
 * Community post rules (pure — unit-tested). Members share personal reflections and self-improvement,
 * not religious rulings or quotations. Anything that looks like a quotation or citation of the Qur'an or
 * hadith is HELD for a moderator, because a wrongly attributed "hadith" on a trusted Islamic site is the
 * main harm this feature could cause. Links, contact details and crisis language are held too.
 */
import { ARABIC, QUOTE_ATTRIBUTION, REFERENCE_LIKE } from "./guidance/validate";
import { detectSafety } from "./guidance/safety";

export const POST_KINDS = ["mahabbah", "reflection", "improvement", "reminder", "question"] as const;
export const REACTIONS = ["mashaallah", "ameen", "fillah"] as const;
export type Reaction = (typeof REACTIONS)[number];
export type PostKind = (typeof POST_KINDS)[number];
export const MIN_LEN = 10, MAX_LEN = 1500;
export const AUTO_HIDE_REPORTS = 3;

export type HoldReason = "religious_citation" | "link_or_contact" | "crisis" | "fiqh";
export type PostDecision = { ok: false; error: "too_short" | "too_long" } | { ok: true; status: "published" | "held"; reasons: HoldReason[]; crisis: boolean };

const RELIGIOUS_QUOTE = [
  /(হাদিস|হাদীস|আয়াত|আয়াত|কুরআনে\s*(আছে|বলা)|রাসূল(ুল্লাহ)?\s*\(?(সা|সাঃ|ﷺ)?\)?\s*বলেছেন|নবী\s*(ﷺ\s*)?বলেছেন|আল্লাহ\s*বলেন)/,
  /\b(hadith|hadeeth|ayah|ayat|verse|quran\s+says|prophet\s*(ﷺ\s*)?said|allah\s+says)\b/i,
];
const LINK_OR_CONTACT = [/https?:\/\//i, /\bwww\./i, /\b[\w.+-]+@[\w-]+\.[\w.]+\b/, /(\+?\d[\d\s-]{8,}\d)/, /[০-৯]{9,}/];
const FIQH = [/\b(halal|haram|fatwa|is it allowed|permissible)\b/i, /(হালাল|হারাম|ফতোয়া|জায়েজ|জায়েয|নাজায়েজ)/];

export function reviewPost(raw: string): PostDecision {
  const body = raw.trim();
  if (body.length < MIN_LEN) return { ok: false, error: "too_short" };
  if (body.length > MAX_LEN) return { ok: false, error: "too_long" };
  return classify(body);
}

function classify(body: string): PostDecision {
  const reasons: HoldReason[] = [];
  const bodyNoSalawat = body.replace(/ﷺ/g, "");
  if (ARABIC.test(bodyNoSalawat) || REFERENCE_LIKE.some((r) => r.test(body)) || QUOTE_ATTRIBUTION.some((r) => r.test(body)) || RELIGIOUS_QUOTE.some((r) => r.test(body))) reasons.push("religious_citation");
  if (LINK_OR_CONTACT.some((r) => r.test(body))) reasons.push("link_or_contact");
  if (FIQH.some((r) => r.test(body))) reasons.push("fiqh");
  const crisis = detectSafety(body).level !== "none";
  if (crisis) reasons.push("crisis");
  return { ok: true, status: reasons.length ? "held" : "published", reasons, crisis };
}

export const COMMENT_MIN = 2, COMMENT_MAX = 600;
/** Comments follow the same holding rules as posts, with shorter length limits ("MashaAllah" is a fine comment). */
export function reviewComment(raw: string): PostDecision {
  const body = raw.trim();
  if (body.length < COMMENT_MIN) return { ok: false, error: "too_short" };
  if (body.length > COMMENT_MAX) return { ok: false, error: "too_long" };
  return classify(body);
}
