/**
 * Rasulullah.org database schema (PROJECT_PLAN.md §5).
 * PostgreSQL 16 + pgvector. Drizzle ORM (see docs/adr/0001-drizzle.md).
 *
 * Integrity rules enforced by the application layer:
 *  - Religious text lives ONLY in `evidence_texts`, loaded by ingestion from licensed sources.
 *  - The LLM never writes into these tables.
 *  - `is_demo = true` rows are blocked in production by `assertNoDemoContent()`.
 */
import { sql } from "drizzle-orm";
import {
  pgTable, pgEnum, text, integer, boolean, timestamp, jsonb, uuid, primaryKey, index, uniqueIndex,
  customType, real, date, vector, smallint,
} from "drizzle-orm/pg-core";

const tsvector = customType<{ data: string }>({ dataType: () => "tsvector" });
const bytea = customType<{ data: Buffer }>({ dataType: () => "bytea" });

const timestamps = {
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
};

/* ───────────────────────────── Enums ───────────────────────────── */
export const trustLevel = pgEnum("trust_level", ["A", "B", "C", "D", "E"]);
/** Religious-content lifecycle. Only `approved` is ever eligible for public distribution (see src/server/publishing.ts). */
export const reviewStatus = pgEnum("review_status", ["draft", "automated_check", "pending_review", "approved", "rejected", "archived"]);
/** Source registry state (licence and operational). Production eligibility requires `verified` for both. */
export const registryStatus = pgEnum("registry_status", ["verified", "pending", "restricted", "rejected"]);
export const evidenceKind = pgEnum("evidence_kind", ["quran_ayah", "hadith", "seerah_event", "sahabi_narrative", "scholar_excerpt", "dua", "editorial_note"]);
export const textRole = pgEnum("text_role", ["original_arabic", "translation", "summary", "explanation"]);
export const licenseType = pgEnum("license_type", ["public_domain", "creative_commons", "provider_terms", "written_permission", "proprietary_internal", "unknown"]);
export const licenseStatus = pgEnum("license_status", ["unverified", "verified", "expired", "rejected"]);
export const roleName = pgEnum("role_name", ["super_admin", "content_reviewer", "hadith_reviewer", "seerah_editor", "translator", "moderator"]);
export const topicKind = pgEnum("topic_kind", ["emotion", "life_area", "worship", "character", "fiqh_area", "akhirah"]);
export const sensitivity = pgEnum("sensitivity", ["normal", "sensitive", "fiqh", "crisis_adjacent"]);
export const pickSection = pgEnum("pick_section", ["quran", "prophetic", "seerah", "sahaba", "dua"]);
export const cardKind = pgEnum("card_kind", ["daily_action", "character_challenge", "reflection_question"]);
export const auditReview = pgEnum("audit_review", ["auto_ok", "sampled", "flagged", "reviewed_ok", "reviewed_bad"]);
export const dateCertainty = pgEnum("date_certainty", ["established", "approximate", "disputed", "unknown"]);

/* ───────────────────────── Auth (Better Auth) ───────────────────────── */
export const user = pgTable("user", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("email_verified").notNull().default(false),
  image: text("image"),
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  locale: text("locale").notNull().default("en"),
  ...timestamps,
});

export const session = pgTable("session", {
  id: text("id").primaryKey(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  token: text("token").notNull().unique(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  ...timestamps,
});

export const account = pgTable("account", {
  id: text("id").primaryKey(),
  accountId: text("account_id").notNull(),
  providerId: text("provider_id").notNull(),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  idToken: text("id_token"),
  accessTokenExpiresAt: timestamp("access_token_expires_at", { withTimezone: true }),
  refreshTokenExpiresAt: timestamp("refresh_token_expires_at", { withTimezone: true }),
  scope: text("scope"),
  password: text("password"),
  ...timestamps,
});

export const verification = pgTable("verification", {
  id: text("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  ...timestamps,
});

export const twoFactor = pgTable("two_factor", {
  id: text("id").primaryKey(),
  secret: text("secret").notNull(),
  backupCodes: text("backup_codes").notNull(),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  verified: boolean("verified").default(true),
  failedVerificationCount: integer("failed_verification_count").default(0),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
});

/* ───────────────────────── Users & privacy ───────────────────────── */
export const userRoles = pgTable("user_roles", {
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  role: roleName("role").notNull(),
  grantedBy: text("granted_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.userId, t.role] })]);

export const consents = pgTable("consents", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(), // terms | privacy | special_category_processing | ai_training_optin
  version: text("version").notNull(),
  grantedAt: timestamp("granted_at", { withTimezone: true }).notNull().defaultNow(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
});

/** Per-user data-encryption key, wrapped by the master key (crypto-shredding on delete). */
export const userKeys = pgTable("user_keys", {
  userId: text("user_id").primaryKey().references(() => user.id, { onDelete: "cascade" }),
  wrappedDek: bytea("wrapped_dek").notNull(),
  keyVersion: integer("key_version").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const userTopics = pgTable("user_topics", {
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  topicId: integer("topic_id").notNull().references(() => topics.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(), // concern | follow
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.userId, t.topicId, t.kind] })]);

/* ───────────────────────── Taxonomy ───────────────────────── */
export const topics = pgTable("topics", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  slug: text("slug").notNull().unique(),
  parentId: integer("parent_id"),
  kind: topicKind("kind").notNull(),
  sensitivity: sensitivity("sensitivity").notNull().default("normal"),
  isActive: boolean("is_active").notNull().default(true),
  ...timestamps,
});

export const topicTranslations = pgTable("topic_translations", {
  topicId: integer("topic_id").notNull().references(() => topics.id, { onDelete: "cascade" }),
  locale: text("locale").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  /** Words/phrases (incl. Banglish) used by the non-AI classifier. Editorial, not religious text. */
  lexicon: text("lexicon").array().notNull().default(sql`'{}'::text[]`),
}, (t) => [primaryKey({ columns: [t.topicId, t.locale] })]);

/* ───────────────────────── Sources & evidence ───────────────────────── */
export const licenses = pgTable("licenses", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: text("name").notNull(),
  type: licenseType("type").notNull(),
  termsUrl: text("terms_url"),
  attributionText: text("attribution_text").notNull(),
  allowsCache: boolean("allows_cache").notNull().default(false),
  allowsEmbed: boolean("allows_embed").notNull().default(false),
  allowsIndex: boolean("allows_index").notNull().default(false),
  status: licenseStatus("status").notNull().default("unverified"),
  notes: text("notes"),
  verifiedBy: text("verified_by"),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  ...timestamps,
});

export const sources = pgTable("sources", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  key: text("key").notNull().unique(), // e.g. quran:uthmani, quran:en.sahih, hadith:bukhari
  kind: text("kind").notNull(), // quran_edition | quran_translation | hadith_collection | hadith_translation | seerah_work | scholar | editorial
  name: text("name").notNull(),
  author: text("author"),
  language: text("language").notNull(),
  provider: text("provider"),
  sourceUrl: text("source_url"),
  licenseId: integer("license_id").references(() => licenses.id),
  trustLevel: trustLevel("trust_level").notNull(),
  // ── Source registry (AUDIT §5, CORRECTION_PLAN P0.2) ──
  licenseStatus: registryStatus("license_status").notNull().default("pending"),
  licenseNotes: text("license_notes"),
  attributionRequired: boolean("attribution_required").notNull().default(true),
  commercialUseAllowed: text("commercial_use_allowed").notNull().default("unknown"), // yes | no | unknown
  storageAllowed: text("storage_allowed").notNull().default("unknown"), // yes | no | limited | unknown
  translationRights: text("translation_rights"),
  apiTermsUrl: text("api_terms_url"),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  verifiedBy: text("verified_by"),
  status: registryStatus("status").notNull().default("pending"),
  transcriptRights: text("transcript_rights"),
  notes: text("notes"),
  ...timestamps,
});

export const evidence = pgTable("evidence", {
  id: uuid("id").primaryKey().defaultRandom(),
  kind: evidenceKind("kind").notNull(),
  canonicalRef: text("canonical_ref").notNull().unique(), // quran:2:286 · hadith:bukhari:6 · seerah:hijrah
  sourceId: integer("source_id").notNull().references(() => sources.id),
  trustLevel: trustLevel("trust_level").notNull(),
  reviewStatus: reviewStatus("review_status").notNull().default("pending_review"),
  isDemo: boolean("is_demo").notNull().default(false),
  version: integer("version").notNull().default(1),
  ...timestamps,
}, (t) => [index("evidence_kind_idx").on(t.kind)]);

export const evidenceTexts = pgTable("evidence_texts", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  evidenceId: uuid("evidence_id").notNull().references(() => evidence.id, { onDelete: "cascade" }),
  locale: text("locale").notNull(), // ar | en | bn
  role: textRole("role").notNull(),
  text: text("text").notNull(),
  translationSourceId: integer("translation_source_id").references(() => sources.id),
  /** SHA-256 of `text` recorded at ingest; verified on read so a swapped or altered text fails closed. */
  textSha256: text("text_sha256"),
  isMachineTranslated: boolean("is_machine_translated").notNull().default(false),
  tsv: tsvector("tsv").generatedAlwaysAs(
    sql`to_tsvector(CASE WHEN locale = 'en' THEN 'english'::regconfig ELSE 'simple'::regconfig END, left(text, 20000))`,
  ),
}, (t) => [
  index("evidence_texts_evidence_idx").on(t.evidenceId),
  index("evidence_texts_tsv_idx").using("gin", t.tsv),
  uniqueIndex("evidence_texts_unique").on(t.evidenceId, t.locale, t.role),
]);

export const quranSurahs = pgTable("quran_surahs", {
  number: smallint("number").primaryKey(),
  nameArabic: text("name_arabic").notNull(),
  transliteration: text("transliteration").notNull(),
  nameEn: text("name_en").notNull(),
  nameBn: text("name_bn").notNull(),
  revelationType: text("revelation_type").notNull(),
  verseCount: smallint("verse_count").notNull(),
});

export const quranReferences = pgTable("quran_references", {
  evidenceId: uuid("evidence_id").primaryKey().references(() => evidence.id, { onDelete: "cascade" }),
  surah: smallint("surah").notNull().references(() => quranSurahs.number),
  ayah: smallint("ayah").notNull(),
  /** SHA-256 of the verse's Arabic text as ingested from the source file. Checked on every read (fail closed). */
  arabicSha256: text("arabic_sha256"),
}, (t) => [uniqueIndex("quran_ref_unique").on(t.surah, t.ayah)]);

export const hadithReferences = pgTable("hadith_references", {
  evidenceId: uuid("evidence_id").primaryKey().references(() => evidence.id, { onDelete: "cascade" }),
  collection: text("collection").notNull(),
  book: integer("book"),
  bookName: text("book_name"),
  hadithNumber: text("hadith_number").notNull(),
  arabicNumber: text("arabic_number"),
  numberScheme: text("number_scheme").notNull().default("fawazahmed0/hadith-api@1"),
  sourceUrl: text("source_url"),
}, (t) => [uniqueIndex("hadith_ref_unique").on(t.collection, t.hadithNumber)]);

export const hadithGradings = pgTable("hadith_gradings", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  evidenceId: uuid("evidence_id").notNull().references(() => evidence.id, { onDelete: "cascade" }),
  grade: text("grade").notNull(),
  grader: text("grader").notNull(),
  isPrimary: boolean("is_primary").notNull().default(false),
}, (t) => [index("hadith_gradings_evidence_idx").on(t.evidenceId)]);

export const evidenceEmbeddings = pgTable("evidence_embeddings", {
  evidenceId: uuid("evidence_id").notNull().references(() => evidence.id, { onDelete: "cascade" }),
  locale: text("locale").notNull(),
  model: text("model").notNull(),
  embedding: vector("embedding", { dimensions: 1536 }).notNull(),
}, (t) => [
  primaryKey({ columns: [t.evidenceId, t.locale, t.model] }),
  index("evidence_embeddings_hnsw").using("hnsw", t.embedding.op("vector_cosine_ops")),
]);

/**
 * Topic → evidence mapping ("Guidance Pack" items). Reviewer-approved rows form the pack.
 * Two distinct approvals are required for trust A–C evidence (MIN_APPROVALS).
 */
export const topicEvidence = pgTable("topic_evidence", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  topicId: integer("topic_id").notNull().references(() => topics.id, { onDelete: "cascade" }),
  evidenceId: uuid("evidence_id").notNull().references(() => evidence.id, { onDelete: "cascade" }),
  section: pickSection("section").notNull(),
  weight: real("weight").notNull().default(1),
  contextNote: text("context_note"), // editorial, reviewer-facing
  assignedBy: text("assigned_by").notNull(), // user id or "seed:editor"
  reviewStatus: reviewStatus("review_status").notNull().default("pending_review"),
  ...timestamps,
}, (t) => [uniqueIndex("topic_evidence_unique").on(t.topicId, t.evidenceId), index("topic_evidence_topic_idx").on(t.topicId)]);

/* ───────────────────────── Seerah CMS ───────────────────────── */
export const seerahPeriods = pgTable("seerah_periods", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  slug: text("slug").notNull().unique(),
  order: integer("order").notNull(),
  nameEn: text("name_en").notNull(),
  nameBn: text("name_bn").notNull(),
});

export const seerahEvents = pgTable("seerah_events", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  slug: text("slug").notNull().unique(),
  evidenceId: uuid("evidence_id").references(() => evidence.id),
  periodId: integer("period_id").notNull().references(() => seerahPeriods.id),
  order: integer("order").notNull().default(0),
  approximateDate: text("approximate_date"),
  dateCertainty: dateCertainty("date_certainty").notNull().default("unknown"),
  location: text("location"),
  people: text("people").array().notNull().default(sql`'{}'::text[]`),
  themes: text("themes").array().notNull().default(sql`'{}'::text[]`),
  reviewStatus: reviewStatus("review_status").notNull().default("draft"),
  isDemo: boolean("is_demo").notNull().default(false),
  authorId: text("author_id"),
  version: integer("version").notNull().default(1),
  ...timestamps,
});

export const seerahEventTranslations = pgTable("seerah_event_translations", {
  eventId: integer("event_id").notNull().references(() => seerahEvents.id, { onDelete: "cascade" }),
  locale: text("locale").notNull(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  narrative: text("narrative").notNull().default(""),
  lessons: text("lessons").array().notNull().default(sql`'{}'::text[]`),
  isMachineTranslated: boolean("is_machine_translated").notNull().default(false),
}, (t) => [primaryKey({ columns: [t.eventId, t.locale] })]);

export const seerahEventLinks = pgTable("seerah_event_links", {
  eventId: integer("event_id").notNull().references(() => seerahEvents.id, { onDelete: "cascade" }),
  evidenceId: uuid("evidence_id").notNull().references(() => evidence.id, { onDelete: "cascade" }),
  relation: text("relation").notNull(), // quran_link | hadith_link
}, (t) => [primaryKey({ columns: [t.eventId, t.evidenceId] })]);

export const bibliographyEntries = pgTable("bibliography_entries", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  eventId: integer("event_id").notNull().references(() => seerahEvents.id, { onDelete: "cascade" }),
  citation: text("citation").notNull(),
  isPrimarySource: boolean("is_primary_source").notNull().default(false),
});

/* ───────────────────────── Editorial cards (feed/today) ───────────────────────── */
export const editorialCards = pgTable("editorial_cards", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  kind: cardKind("kind").notNull(),
  topicId: integer("topic_id").references(() => topics.id),
  textEn: text("text_en").notNull(),
  textBn: text("text_bn").notNull(),
  reviewStatus: reviewStatus("review_status").notNull().default("pending_review"),
  ...timestamps,
});

/* ───────────────────────── Guidance ───────────────────────── */
export const guidanceSessions = pgTable("guidance_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").references(() => user.id, { onDelete: "cascade" }),
  locale: text("locale").notNull(),
  topicIds: integer("topic_ids").array().notNull().default(sql`'{}'::int[]`),
  safetyLevel: text("safety_level").notNull().default("none"), // none | elevated | crisis
  fiqh: boolean("fiqh").notNull().default(false),
  mode: text("mode").notNull(), // composed | evidence_only | crisis
  ...timestamps,
}, (t) => [index("guidance_sessions_user_idx").on(t.userId)]);

/** User text + AI output, encrypted with the user's DEK. Anonymous sessions store nothing here. */
export const guidanceMessages = pgTable("guidance_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionId: uuid("session_id").notNull().references(() => guidanceSessions.id, { onDelete: "cascade" }),
  role: text("role").notNull(), // user | assistant
  encContent: bytea("enc_content").notNull(),
  schemaVersion: integer("schema_version").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const guidanceCitations = pgTable("guidance_citations", {
  sessionId: uuid("session_id").notNull().references(() => guidanceSessions.id, { onDelete: "cascade" }),
  evidenceId: uuid("evidence_id").notNull().references(() => evidence.id, { onDelete: "cascade" }),
  section: text("section").notNull(),
  rank: integer("rank").notNull(),
}, (t) => [primaryKey({ columns: [t.sessionId, t.evidenceId] }), index("guidance_citations_evidence_idx").on(t.evidenceId)]);

/**
 * Claim → citation → source (CORRECTION_PLAN P0.4). One row per statement shown in an answer.
 * No user or generated text is stored here (that lives encrypted in guidance_messages); only structure.
 */
export const guidanceClaims = pgTable("guidance_claims", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionId: uuid("session_id").notNull().references(() => guidanceSessions.id, { onDelete: "cascade" }),
  section: text("section").notNull(), // quran | prophetic | dua | seerah | application | action
  position: integer("position").notNull(),
  kind: text("kind").notNull(), // source | application
  textHash: text("text_hash").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("guidance_claims_session_idx").on(t.sessionId)]);

export const guidanceClaimCitations = pgTable("guidance_claim_citations", {
  claimId: uuid("claim_id").notNull().references(() => guidanceClaims.id, { onDelete: "cascade" }),
  evidenceId: uuid("evidence_id").notNull().references(() => evidence.id, { onDelete: "cascade" }),
  sourceId: integer("source_id").notNull().references(() => sources.id),
}, (t) => [primaryKey({ columns: [t.claimId, t.evidenceId] })]);

/** Automated religious-content QA alerts (Qur'an integrity failures, leakage, broken citations). */
export const qaAlerts = pgTable("qa_alerts", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  check: text("check").notNull(),
  severity: text("severity").notNull(), // critical | warning
  subject: text("subject").notNull(),
  details: jsonb("details").notNull().default(sql`'{}'::jsonb`),
  occurrences: integer("occurrences").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  resolvedBy: text("resolved_by"),
}, (t) => [uniqueIndex("qa_alerts_open_unique").on(t.check, t.subject).where(sql`resolved_at IS NULL`)]);

/** No user text here — only pipeline metadata (safe for reviewers). */
export const aiAnswerAudits = pgTable("ai_answer_audits", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionId: uuid("session_id").references(() => guidanceSessions.id, { onDelete: "set null" }),
  pipelineVersion: text("pipeline_version").notNull(),
  model: text("model"),
  topicIds: integer("topic_ids").array().notNull().default(sql`'{}'::int[]`),
  retrievedIds: text("retrieved_ids").array().notNull().default(sql`'{}'::text[]`),
  citedIds: text("cited_ids").array().notNull().default(sql`'{}'::text[]`),
  /** AI-written application text only (no user text), kept so reviewers can judge it. */
  applicationSnapshot: jsonb("application_snapshot"),
  validator: jsonb("validator").notNull(),
  mode: text("mode").notNull(),
  safetyLevel: text("safety_level").notNull(),
  fiqh: boolean("fiqh").notNull().default(false),
  latencyMs: integer("latency_ms"),
  review: auditReview("review").notNull().default("auto_ok"),
  reviewerId: text("reviewer_id"),
  reviewNote: text("review_note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("ai_audits_review_idx").on(t.review)]);

/* ───────────────────────── Personal ───────────────────────── */
export const bookmarks = pgTable("bookmarks", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  targetType: text("target_type").notNull(), // evidence | seerah_event | guidance_session
  targetId: text("target_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("bookmarks_unique").on(t.userId, t.targetType, t.targetId)]);

export const quranProgress = pgTable("quran_progress", {
  userId: text("user_id").primaryKey().references(() => user.id, { onDelete: "cascade" }),
  lastSurah: smallint("last_surah").notNull(),
  lastAyah: smallint("last_ayah").notNull(),
  surahsOpened: smallint("surahs_opened").array().notNull().default(sql`'{}'::smallint[]`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const actionCompletions = pgTable("action_completions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  cardKey: text("card_key").notNull(), // today:<date>:<slot> | guidance:<session>:<n> | card:<id>
  label: text("label"),
  day: date("day").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("action_completions_unique").on(t.userId, t.cardKey)]);

/** "Days you returned to guidance" — no streaks. */
export const returnDays = pgTable("return_days", {
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  day: date("day").notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.day] })]);

export const feedActions = pgTable("feed_actions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  itemKey: text("item_key").notNull(),
  action: text("action").notNull(), // seen | saved | completed | not_relevant
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("feed_actions_user_idx").on(t.userId, t.createdAt)]);

export const journals = pgTable("journals", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  promptKey: text("prompt_key").notNull(),
  encBody: bytea("enc_body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ───────────────────────── Moderation, review, audit ───────────────────────── */
export const reports = pgTable("reports", {
  id: uuid("id").primaryKey().defaultRandom(),
  reporterId: text("reporter_id").references(() => user.id, { onDelete: "set null" }),
  targetType: text("target_type").notNull(),
  targetId: text("target_id").notNull(),
  reason: text("reason").notNull(), // wrong_citation | wrong_translation | inappropriate | other
  details: text("details"),
  status: text("status").notNull().default("open"), // open | resolved | dismissed
  handledBy: text("handled_by"),
  ...timestamps,
});

export const scholarReviews = pgTable("scholar_reviews", {
  id: uuid("id").primaryKey().defaultRandom(),
  targetType: text("target_type").notNull(), // topic_evidence | seerah_event | evidence | editorial_card | source | ai_answer
  targetId: text("target_id").notNull(),
  /** Kept without FK so review history survives account deletion (audit trail). */
  reviewerId: text("reviewer_id").notNull(),
  decision: text("decision").notNull(), // approve | correct | add_citation | reject | flag_uncertain | request_changes
  comment: text("comment"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("scholar_reviews_target_idx").on(t.targetType, t.targetId)]);

export const contentVersions = pgTable("content_versions", {
  id: uuid("id").primaryKey().defaultRandom(),
  targetType: text("target_type").notNull(),
  targetId: text("target_id").notNull(),
  version: integer("version").notNull(),
  snapshot: jsonb("snapshot").notNull(),
  authorId: text("author_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("content_versions_target_idx").on(t.targetType, t.targetId)]);

export const crisisResources = pgTable("crisis_resources", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  countryCode: text("country_code").notNull(), // ISO-3166 alpha-2 or "*" for global
  category: text("category").notNull(), // emergency | suicide | abuse | child | general
  name: text("name").notNull(),
  phone: text("phone"),
  url: text("url"),
  languages: text("languages").array().notNull().default(sql`'{}'::text[]`),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  verifiedBy: text("verified_by"),
  isActive: boolean("is_active").notNull().default(true),
});

export const auditLogs = pgTable("audit_logs", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  actorId: text("actor_id"),
  action: text("action").notNull(),
  targetType: text("target_type"),
  targetId: text("target_id"),
  meta: jsonb("meta"),
  at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
});

/** Aggregated counters only — never free text, never per-user religious concerns. */
export const metricsDaily = pgTable("metrics_daily", {
  day: date("day").notNull(),
  metric: text("metric").notNull(),
  dimension: text("dimension").notNull().default(""),
  value: integer("value").notNull().default(0),
}, (t) => [primaryKey({ columns: [t.day, t.metric, t.dimension] })]);

export const rateLimits = pgTable("rate_limits", {
  key: text("key").primaryKey(),
  windowStart: timestamp("window_start", { withTimezone: true }).notNull(),
  count: integer("count").notNull(),
});

/* ───────────────────────── Community (members' own posts) ───────────────────────── */
/**
 * Members' personal reflections and self-improvement notes. NOT religious guidance: posts that quote or cite
 * Qur'an/hadith (Arabic script, verse/hadith references) or contain links are held for a moderator, and
 * posts are hidden automatically after enough reports.
 */
export const communityPostStatus = pgEnum("community_post_status", ["published", "held", "hidden", "removed"]);
export const communityPosts = pgTable("community_posts", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(), // reflection | improvement | reminder | question
  body: text("body").notNull(),
  locale: text("locale").notNull().default("bn"),
  status: communityPostStatus("status").notNull().default("published"),
  heldReason: text("held_reason"),
  reportCount: integer("report_count").notNull().default(0),
  moderatedBy: text("moderated_by"),
  ...timestamps,
}, (t) => [index("community_posts_feed_idx").on(t.status, t.createdAt), index("community_posts_user_idx").on(t.userId)]);

export const communityReactions = pgTable("community_reactions", {
  postId: uuid("post_id").notNull().references(() => communityPosts.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(), // mashaallah | ameen
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.postId, t.userId, t.kind] })]);

/** Collective salawat: each member records how many times they sent blessings on the Prophet ﷺ today. */
export const salawatLog = pgTable("salawat_log", {
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  day: date("day").notNull(),
  count: integer("count").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.userId, t.day] }), index("salawat_day_idx").on(t.day)]);

export const communityComments = pgTable("community_comments", {
  id: uuid("id").primaryKey().defaultRandom(),
  postId: uuid("post_id").notNull().references(() => communityPosts.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  status: communityPostStatus("status").notNull().default("published"),
  heldReason: text("held_reason"),
  reportCount: integer("report_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("community_comments_post_idx").on(t.postId, t.createdAt)]);
