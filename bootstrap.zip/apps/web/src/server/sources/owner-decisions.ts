/**
 * OWNER LICENCE DECISIONS — decisions the site owner took explicitly (not engineering defaults).
 *
 * 2026-09-28: the owner instructed, in writing, that the Qur'an Arabic text, both Qur'an translations and
 * the hadith collections/translations be published under the owner's responsibility, pending replacement of
 * the translations with sources that have explicit reuse terms (QuranEnc / HadeethEnc).
 *
 * Applied by scripts/ingest-sources.ts ONLY to sources that are still `pending`; any later decision made in
 * /admin/sources or with `pnpm source:verify` always wins and is never overwritten.
 */
export const OWNER_DECISION = {
  by: "owner (instruction in chat, 2026-09-28)",
  at: new Date("2026-09-28T00:00:00Z"),
  note:
    "Published on the site owner's explicit instruction and responsibility (2026-09-28). Terms as researched are recorded above; " +
    "translations are to be replaced with QuranEnc/HadeethEnc editions that carry explicit reuse terms. Re-review before any commercial use.",
};

export const OWNER_VERIFIED_KEYS: string[] = [
  "quran:uthmani",
  "quran:en.sahih",
  "quran:bn.muhiuddin",
  ...["bukhari", "muslim", "nawawi", "tirmidhi", "abudawud"].flatMap((c) => [`hadith:${c}`, `hadith:${c}:en`, `hadith:${c}:bn`]),
];

/**
 * OWNER REVIEW DECISION — 2026-09-29: the owner instructed, in writing ("Owner হিসেবে সব approve"), that the
 * seeded candidate content be published: all seed topic→evidence mappings, the seeded editorial cards and the
 * 26 events of Seerah timeline v1 (plus the Rasulullah.org editorial Seerah source they belong to).
 *
 * Applied by scripts/apply-owner-decisions.ts ONLY to rows that are still `pending_review` and seed-owned.
 * Anything a reviewer has since rejected, archived or edited is never touched, and every row approved this
 * way gets a scholar_reviews entry so it stays traceable and reversible from /admin/review.
 * New content added after this date (e.g. Seerah timeline v2) is NOT covered and stays pending.
 */
export const OWNER_REVIEW_DECISION = {
  by: "owner-decision:2026-09-29",
  at: new Date("2026-09-29T00:00:00Z"),
  comment: "Approved on the site owner's explicit instruction (2026-09-29); pending scholar re-review.",
};
/** 2026-09-29 (second instruction: "৩৭টাও approve … ja ja lagw shob approve"): also the recitation audio source. */
export const OWNER_VERIFIED_EDITORIAL_KEYS = ["editorial:seerah", "audio:everyayah"];
/** Seerah timeline v1 slugs covered by the 2026-09-29 decision. */
export const OWNER_APPROVED_SEERAH_V1 = [
  "born-on-a-monday", "opening-of-the-chest", "rebuilding-the-kabah", "revelation-in-hira", "arise-and-warn", "call-from-safa",
  "moon-split", "insult-at-the-kabah", "migration-to-abyssinia", "death-of-abu-talib", "hardest-day-taif", "isra-and-miraj",
  "pledge-of-aqabah", "the-hijrah", "building-the-mosque", "brotherhood-in-madinah", "battle-of-badr", "battle-of-uhud",
  "battle-of-the-trench", "treaty-of-hudaybiyyah", "khaybar", "conquest-of-makkah", "battle-of-hunayn", "tabuk-and-kab-ibn-malik",
  "farewell-hajj", "the-final-days",
];

/**
 * 2026-09-29, second owner instruction: approve Seerah timeline v2 (37 events) and everything else still pending.
 * Only these v2 slugs are covered — later additions stay pending.
 */
export const OWNER_APPROVED_SEERAH_V2 = [
  "death-of-ibrahim", "woman-at-the-grave", "umm-sulaym-and-abu-talha", "umm-salama-dua", "bedouin-in-the-mosque", "bedouin-pulls-his-cloak",
  "anas-ten-years", "do-not-become-angry", "thumama-ibn-uthal", "hatib-letter", "the-slander-ifk", "the-guest-and-the-lamp", "abu-huraira-hunger",
  "abdur-rahman-and-the-market", "hakim-and-the-upper-hand", "whoever-refrains-from-asking", "the-poor-and-the-dhikr", "fatima-asks-for-a-servant",
  "armour-mortgaged", "the-palm-mat", "the-wet-grain", "sad-leave-heirs-rich", "serving-his-family", "three-men-and-extreme-worship",
  "salman-and-abu-darda", "jabir-marries-for-his-sisters", "kissing-al-hasan", "shortening-prayer-for-a-child", "your-mother-then-your-mother",
  "asma-and-her-mother", "visiting-sad-ibn-ubada", "visiting-the-jewish-boy", "i-am-ruined", "if-fatima-stole", "abu-dharr-and-office",
  "muadh-sent-to-yemen", "grateful-servant-night-prayer",
];

/**
 * Crisis resources: numbers checked against public sources on 2026-09-29 before being marked verified
 * (Samaritans site; 988lifeline.org / SAMHSA; Bangladesh 999 national emergency service; EU 112; Saudi 911 unified
 * number; Malaysia 999). Only rows whose country + number match exactly are marked; anything else stays unverified.
 */
export const CHECKED_CRISIS_NUMBERS: [country: string, phone: string | null][] = [
  ["*", null], ["BD", "999"], ["GB", "999"], ["GB", "116 123"], ["US", "911"], ["US", "988"], ["EU", "112"], ["SA", "911"], ["MY", "999"],
];

/**
 * 2026-10-01: the owner's standing instruction ("ja ja lagw shob approve", "seerah ke aro boro kore daw") covers
 * Seerah timeline v3, prepared under the same verification rules.
 */
export const OWNER_APPROVED_SEERAH_V3 = [
  "remembering-khadijah", "abu-dharr-accepts-islam", "umar-accepts-islam", "bilal-freed-by-abu-bakr", "the-first-adhan", "change-of-qibla",
  "anas-ibn-an-nadr", "hamza-and-wahshi", "sad-ibn-muadh", "abu-jandal-at-hudaybiyyah", "bilals-footsteps-in-paradise", "he-wept-at-the-quran",
  "his-grandchild-dying", "abu-bakr-leads-the-prayer", "fatimas-tears-and-smile",
];
