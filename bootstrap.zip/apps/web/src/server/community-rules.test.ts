import { describe, expect, it } from "vitest";
import { reviewComment, reviewPost } from "./community-rules";

describe("community post rules", () => {
  it("publishes a personal reflection", () => {
    const r = reviewPost("Today I prayed Fajr on time for the first week in a row. Small steps, but I feel calmer.");
    expect(r).toMatchObject({ ok: true, status: "published", reasons: [] });
  });
  it("publishes Bangla self-improvement", () => {
    expect(reviewPost("এই সপ্তাহে মোবাইল কম ব্যবহার করে পরিবারের সাথে বেশি সময় কাটিয়েছি, আলহামদুলিল্লাহ।")).toMatchObject({ ok: true, status: "published" });
  });
  it("allows ﷺ in a reflection", () => {
    expect(reviewPost("Reading about the Prophet ﷺ serving his family changed how I help at home.")).toMatchObject({ status: "published" });
  });
  it("holds anything that quotes or cites Qur'an/hadith", () => {
    for (const t of ["The Prophet said: \"smile is charity\" so smile more", "Bukhari 1234 says we must do this", "A hadith says patience is key to everything", "রাসূল (সাঃ) বলেছেন হাসি মুখে কথা বলা সদকা", "Remember 2:286 when things are hard", "সূরা বাকারার শেষ আয়াত পড়ুন প্রতিদিন রাতে"])
      expect(reviewPost(t), t).toMatchObject({ ok: true, status: "held", reasons: expect.arrayContaining(["religious_citation"]) });
  });
  it("holds Arabic script", () => {
    expect(reviewPost("Say this every morning: سبحان الله many times")).toMatchObject({ status: "held" });
  });
  it("holds links, contacts, fiqh questions and crisis language", () => {
    expect(reviewPost("Join my group at https://example.com for more reminders")).toMatchObject({ status: "held", reasons: ["link_or_contact"] });
    expect(reviewPost("Call me on 01712345678 for Quran classes please")).toMatchObject({ status: "held" });
    expect(reviewPost("Is it haram to work in a bank? Please answer brothers")).toMatchObject({ status: "held", reasons: ["fiqh"] });
    expect(reviewPost("I want to kill myself, nothing matters anymore")).toMatchObject({ status: "held", crisis: true });
  });
  it("rejects too short / too long", () => {
    expect(reviewPost("hi")).toEqual({ ok: false, error: "too_short" });
    expect(reviewPost("a".repeat(1501))).toEqual({ ok: false, error: "too_long" });
  });

  it("comments: short replies publish, citations are held, limits enforced", () => {
    expect(reviewComment("MashaAllah")).toMatchObject({ ok: true, status: "published" });
    expect(reviewComment("আমিন")).toMatchObject({ ok: true, status: "published" });
    expect(reviewComment("A hadith says you must do this")).toMatchObject({ status: "held" });
    expect(reviewComment("x")).toEqual({ ok: false, error: "too_short" });
    expect(reviewComment("a".repeat(601))).toEqual({ ok: false, error: "too_long" });
  });
});
