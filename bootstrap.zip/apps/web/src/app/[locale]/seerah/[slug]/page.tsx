import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { CalendarDays, MapPin, Users } from "lucide-react";
import { Container, DemoBadge } from "@rasulullah/ui";
import { Link } from "@/i18n/navigation";
import { getSeerahEvent, listSeerah } from "@/server/seerah";
import { getEvidence } from "@/server/evidence";
import { EvidenceBlock } from "@/components/evidence/evidence-block";
import { BookmarkButton } from "@/components/evidence/bookmark-button";
import { ReportButton } from "@/components/evidence/report-button";
import { getViewer } from "@/server/publishing";

type P = { params: Promise<{ locale: string; slug: string }> };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const { locale, slug } = await params;
  const e = await getSeerahEvent(slug, locale === "bn" ? "bn" : "en", await getViewer());
  if (!e) return {};
  return { title: e.title, description: e.summary, robots: e.isDemo || e.reviewStatus !== "approved" ? { index: false } : undefined };
}

export default async function SeerahEventPage({ params }: P) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const loc = locale === "bn" ? "bn" : "en";
  const viewer = await getViewer();
  const e = await getSeerahEvent(slug, loc, viewer);
  if (!e) notFound();
  const t = await getTranslations("seerah");
  const ev = await getEvidence(e.links.map((l) => l.evidenceId), loc, viewer);
  const linked = e.links.map((l) => ev.get(l.evidenceId)).filter((v): v is NonNullable<typeof v> => !!v);
  const story = linked.filter((v) => !v.quran);
  const quranLinks = linked.filter((v) => !!v.quran);
  const { events } = await listSeerah(loc, viewer);
  const related = events.filter((x) => x.slug !== e.slug && (x.periodId === e.periodId || x.themes.some((th) => e.themes.includes(th)))).slice(0, 3);
  const jsonLd = { "@context": "https://schema.org", "@type": "Article", headline: e.title, description: e.summary, inLanguage: loc, dateModified: e.updatedAt.toISOString() };

  return (
    <Container className="py-12 sm:py-16">
      {!e.isDemo && e.reviewStatus === "approved" ? <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} /> : null}
      <article className="mx-auto max-w-3xl">
        <p className="text-sm text-fg-muted"><Link href="/seerah" className="hover:underline">{t("title")}</Link> / {loc === "bn" ? e.period?.nameBn : e.period?.nameEn}</p>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          {e.isDemo ? <DemoBadge /> : null}
          {e.reviewStatus !== "approved" ? <span className="rounded-md bg-surface-muted px-2 py-0.5 text-xs text-fg-muted">{t("notReviewed")}</span> : <span className="rounded-md bg-green-100 px-2 py-0.5 text-xs text-green-900">{t("reviewed")}</span>}
        </div>
        <h1 className="mt-3 text-balance text-4xl font-semibold tracking-tight text-fg">{e.title}</h1>
        <dl className="mt-5 flex flex-wrap gap-x-6 gap-y-2 text-sm text-fg-muted">
          {e.date ? <div className="flex items-center gap-1.5"><CalendarDays className="h-4 w-4" aria-hidden /><dt className="sr-only">{t("date")}</dt><dd>{e.date} · {t(`certainty.${e.certainty}`)}</dd></div> : null}
          {e.location ? <div className="flex items-center gap-1.5"><MapPin className="h-4 w-4" aria-hidden /><dt className="sr-only">{t("location")}</dt><dd>{e.location}</dd></div> : null}
          {e.people.length ? <div className="flex items-center gap-1.5"><Users className="h-4 w-4" aria-hidden /><dt className="sr-only">{t("people")}</dt><dd>{e.people.join(", ")}</dd></div> : null}
        </dl>
        <p className="mt-8 text-pretty text-xl leading-relaxed text-fg">{e.summary}</p>
        {e.narrative ? <div className="mt-6 whitespace-pre-line leading-relaxed text-fg">{e.narrative}</div> : null}

        {story.length ? (
          <section className="mt-10">
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-gold-700">{t("storyEyebrow")}</p>
            <h2 className="mt-1 text-2xl font-semibold text-fg">{t("storyTitle")}</h2>
            <p className="mt-2 text-fg-muted">{t("storyLead")}</p>
            <div className="mt-5 flex flex-col gap-6">
              {story.map((v) => <EvidenceBlock key={v.id} evidence={v} kind="prophetic" />)}
            </div>
          </section>
        ) : null}

        {quranLinks.length ? (
          <section className="mt-10">
            <h2 className="mb-4 text-lg font-semibold text-fg">{t("quranTitle")}</h2>
            <div className="flex flex-col gap-5">{quranLinks.map((v) => <EvidenceBlock key={v.id} evidence={v} kind="quran" compact />)}</div>
          </section>
        ) : null}

        {e.lessons.length ? (
          <section className="mt-10 rounded-(--radius-card) bg-green-900 p-6 text-ivory-50">
            <h2 className="text-lg font-semibold">{t("lessons")}</h2>
            <ul className="mt-3 flex flex-col gap-2">{e.lessons.map((l, i) => <li key={i} className="border-s-2 border-gold-500 ps-3">{l}</li>)}</ul>
            <p className="mt-4 text-xs text-green-200">{t("lessonsNote")}</p>
          </section>
        ) : null}

        <section className="mt-10 rounded-(--radius-card) border border-gold-500/40 bg-gold-500/5 p-6">
          <h2 className="text-lg font-semibold text-fg">{t("reflectTitle")}</h2>
          <p className="mt-2 text-fg">{t("reflectBody")}</p>
          <Link href="/mahabbah" className="mt-4 inline-block rounded-full bg-green-900 px-5 py-2 text-sm font-medium text-ivory-50 hover:bg-green-800">{t("sendSalawat")}</Link>
        </section>

        <section className="mt-10">
          <h2 className="mb-3 text-lg font-semibold text-fg">{t("bibliography")}</h2>
          <ul className="list-disc ps-5 text-sm text-fg">{e.bib.map((b) => <li key={b.id}>{b.citation}{b.isPrimarySource ? ` · ${t("primary")}` : ""}</li>)}</ul>
        </section>

        <div className="mt-8 flex flex-wrap gap-2">
          <BookmarkButton targetType="seerah_event" targetId={e.slug} />
          <ReportButton targetType="seerah_event" targetId={e.slug} />
        </div>

        {related.length ? (
          <section className="mt-12 border-t border-line pt-8">
            <h2 className="mb-4 text-lg font-semibold text-fg">{t("related")}</h2>
            <ul className="grid gap-3 sm:grid-cols-3">{related.map((r) => <li key={r.slug}><Link href={`/seerah/${r.slug}`} className="block rounded-2xl border border-line bg-surface p-4 text-sm font-medium text-fg hover:border-gold-500/60">{r.title}</Link></li>)}</ul>
          </section>
        ) : null}
      </article>
    </Container>
  );
}
