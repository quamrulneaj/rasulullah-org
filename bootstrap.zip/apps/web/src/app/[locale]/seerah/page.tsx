import type { Metadata } from "next";
import { PlaylistSection } from "@/components/learn/playlist-section";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { Container, DemoBadge } from "@rasulullah/ui";
import { Link } from "@/i18n/navigation";
import { listSeerah } from "@/server/seerah";
import { topicsBySlugs } from "@/server/guidance/pipeline";
import { getViewer } from "@/server/publishing";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "pages.seerah" });
  return { title: t("title"), description: t("lead") };
}

export default async function SeerahHome({ params, searchParams }: { params: Promise<{ locale: string }>; searchParams: Promise<{ view?: string }> }) {
  const { locale } = await params;
  const { view = "timeline" } = await searchParams;
  setRequestLocale(locale);
  const loc = locale === "bn" ? "bn" : "en";
  const t = await getTranslations("seerah");
  const tl = await getTranslations("learn.sections");
  const tp = await getTranslations("pages.seerah");
  const { periods, events } = await listSeerah(loc, await getViewer());
  const views = ["timeline", "themes", "people", "places", "lessons"] as const;
  const themeSlugs = [...new Set(events.flatMap((e) => e.themes))];
  const themes = await topicsBySlugs(themeSlugs);

  return (
    <Container className="py-12 sm:py-16">
      <header className="max-w-2xl">
        <h1 className="text-4xl font-semibold tracking-tight text-fg sm:text-5xl">{tp("title")}</h1>
        <p className="mt-3 text-lg text-fg-muted">{tp("lead")}</p>
        <p className="mt-4 rounded-xl border border-line bg-surface p-3 text-sm text-fg-muted">{t("integrity")}</p>
      </header>

      <nav aria-label={t("views")} className="mt-8 flex gap-2 overflow-x-auto pb-1">
        {views.map((v) => (
          <Link key={v} href={`/seerah?view=${v}`} aria-current={view === v ? "page" : undefined} className={`whitespace-nowrap rounded-full border px-4 py-2 text-sm ${view === v ? "border-brand bg-brand text-brand-contrast" : "border-line bg-surface text-fg hover:bg-surface-muted"}`}>
            {t(`view.${v}`)}
          </Link>
        ))}
      </nav>

      {view === "timeline" ? (
        <ol className="mt-10 flex flex-col gap-10">
          {periods.map((p, i) => {
            const evs = events.filter((e) => e.periodId === p.id);
            return (
              <li key={p.id} className="grid gap-4 md:grid-cols-[14rem_1fr]">
                <div className="flex items-center gap-3 md:block">
                  <span className="text-sm tabular-nums text-accent-fg">{String(i + 1).padStart(2, "0")}</span>
                  <h2 className="text-lg font-semibold text-fg md:mt-1">{loc === "bn" ? p.nameBn : p.nameEn}</h2>
                </div>
                <div className="flex flex-col gap-3 border-s border-gold-500/40 ps-5">
                  {evs.length ? evs.map((e) => (
                    <Link key={e.slug} href={`/seerah/${e.slug}`} className="rounded-2xl border border-line bg-surface p-4 transition-colors hover:border-gold-500/60">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs text-fg-muted">{e.date}</span>
                        {e.isDemo ? <DemoBadge /> : e.reviewStatus !== "approved" ? <span className="rounded-md bg-surface-muted px-2 py-0.5 text-xs text-fg-muted">{t("notReviewed")}</span> : null}
                      </div>
                      <h3 className="mt-1 font-semibold text-fg">{e.title}</h3>
                      <p className="mt-1 line-clamp-2 text-sm text-fg-muted">{e.summary}</p>
                    </Link>
                  )) : <p className="text-sm text-fg-muted">{t("comingSoon")}</p>}
                </div>
              </li>
            );
          })}
        </ol>
      ) : view === "themes" ? (
        <ul className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {themes.map((th) => (
            <li key={th.slug} className="rounded-2xl border border-line bg-surface p-4">
              <h2 className="font-semibold text-fg">{loc === "bn" ? th.nameBn : th.nameEn}</h2>
              <ul className="mt-2 flex flex-col gap-1 text-sm">
                {events.filter((e) => e.themes.includes(th.slug)).map((e) => <li key={e.slug}><Link href={`/seerah/${e.slug}`} className="text-accent-fg hover:underline">{e.title}</Link></li>)}
              </ul>
            </li>
          ))}
        </ul>
      ) : view === "lessons" ? (
        <ul className="mt-10 flex flex-col gap-3">
          {events.flatMap((e) => e.lessons.map((l, i) => (
            <li key={e.slug + i} className="rounded-2xl border border-line bg-surface p-4">
              <p className="text-fg">{l}</p>
              <Link href={`/seerah/${e.slug}`} className="mt-1 inline-block text-sm text-accent-fg hover:underline">{e.title}</Link>
            </li>
          )))}
        </ul>
      ) : (
        <ul className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[...new Set(events.flatMap((e) => (view === "people" ? e.people : e.location ? [e.location] : [])))].map((name) => (
            <li key={name} className="rounded-2xl border border-line bg-surface p-4">
              <h2 className="font-semibold text-fg">{name}</h2>
              <ul className="mt-2 flex flex-col gap-1 text-sm">
                {events.filter((e) => (view === "people" ? e.people.includes(name) : e.location === name)).map((e) => <li key={e.slug}><Link href={`/seerah/${e.slug}`} className="text-accent-fg hover:underline">{e.title}</Link></li>)}
              </ul>
            </li>
          ))}
        </ul>
      )}
      <PlaylistSection groups={["seerah"]} locale={locale} title={tl("seerahTitle")} />
    </Container>
  );
}
