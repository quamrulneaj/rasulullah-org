import type { Metadata } from "next";
import { surahName } from "@/lib/surah-names-bn";
import { notFound } from "next/navigation";
import { and, eq, inArray } from "drizzle-orm";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Container } from "@rasulullah/ui";
import { Link } from "@/i18n/navigation";
import { quran } from "@/server/providers/quran";
import { getSession } from "@/server/session";
import { db, schema as s } from "@/server/db";
import { BookmarkButton } from "@/components/evidence/bookmark-button";
import { ReportButton } from "@/components/evidence/report-button";
import { AyahAudio } from "@/components/quran/ayah-audio";
import { SurahPlayer } from "@/components/quran/surah-player";
import { ProgressTracker } from "@/components/quran/progress-tracker";
import { QuranUnavailable } from "@/components/quran/quran-unavailable";
import { getViewer } from "@/server/publishing";

type P = { params: Promise<{ locale: string; surah: string }> };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const { surah } = await params;
  const n = Number(surah);
  const list = await quran.getSurahs();
  const meta = list.find((x) => x.number === n);
  return meta ? { title: `${meta.transliteration} (${meta.nameEn}) · Qur'an ${n}` } : {};
}

export default async function SurahPage({ params }: P) {
  const { locale, surah } = await params;
  setRequestLocale(locale);
  const n = Number(surah);
  if (!Number.isInteger(n) || n < 1 || n > 114) notFound();
  const loc = locale === "bn" ? "bn" : "en";
  const viewer = await getViewer();
  const read = await quran.getSurah(n, loc, viewer);
  if (!read.ok && read.reason === "not_found") notFound();
  if (!read.ok) return <QuranUnavailable />;
  const data = read.data;
  const t = await getTranslations("quran");
  const session = await getSession();
  const rec = quran.getRecitations()[0]!;
  const ids = data.ayat.map((a) => a.evidenceId);
  const saved = session ? new Set((await db.select({ id: s.bookmarks.targetId }).from(s.bookmarks).where(and(eq(s.bookmarks.userId, session.user.id), eq(s.bookmarks.targetType, "evidence"), inArray(s.bookmarks.targetId, ids)))).map((r) => r.id)) : new Set<string>();
  const translations = await quran.getTranslations();
  // Basmala shown above surahs (except 1 and 9) is rendered from the stored text of 1:1 — never hard-coded.
  const basmalaRead = n !== 1 && n !== 9 ? await quran.getAyah(1, 1, loc, viewer) : null;
  if (basmalaRead && !basmalaRead.ok) return <QuranUnavailable />;
  const basmala = basmalaRead?.ok ? basmalaRead.data.arabic : null;
  const tr = translations.find((x) => x.language === loc);
  const trVerified = tr?.licenseStatus === "verified" && tr?.status === "verified";

  return (
    <Container className="py-10 sm:py-14">
      <ProgressTracker surah={n} enabled={!!session} />
      <header className="mx-auto max-w-3xl text-center">
        <p className="text-sm text-fg-muted">{t("surahNo", { n })} · {data.meta.revelationType === "meccan" ? t("meccan") : t("medinan")} · {data.meta.verseCount} {t("ayat")}</p>
        <h1 lang="ar" dir="rtl" className="font-arabic mt-3 text-5xl text-fg">{data.meta.nameArabic}</h1>
        <p className="mt-3 text-2xl font-semibold text-fg">{surahName(n, data.meta.transliteration, loc)}</p>
        <p className="text-fg-muted">{loc === "bn" ? data.meta.nameBn : data.meta.nameEn}</p>
        {basmala ? <p lang="ar" dir="rtl" className="font-arabic mt-8 text-3xl text-fg">{basmala}</p> : null}
      </header>

      <SurahPlayer surah={n} ayat={data.ayat.map((a) => a.ayah)} urls={data.ayat.map((a) => rec.urlFor(n, a.ayah))} basmalaUrl={n !== 1 && n !== 9 ? rec.urlFor(1, 1) : null} />

      <ol className="mx-auto mt-6 flex max-w-3xl flex-col divide-y divide-line">
        {data.ayat.map((a) => (
          <li key={a.ayah} id={`ayah-${a.ayah}`} data-ayah={a.ayah} className="scroll-mt-24 py-7 transition-colors [&.is-reciting]:bg-gold-500/10 [&.is-reciting]:-mx-4 [&.is-reciting]:px-4 [&.is-reciting]:rounded-2xl">
            <p lang="ar" dir="rtl" className="font-arabic text-[1.9rem] leading-[2.35] text-fg">
              {a.arabic} <span className="text-lg text-accent-fg">{"\uFD3F"}{a.ayah.toLocaleString("ar-EG")}{"\uFD3E"}</span>
            </p>
            <p className="mt-4 text-[1.05rem] leading-relaxed text-fg" lang={loc}>
              <span className="me-2 text-sm font-semibold tabular-nums text-accent-fg">{n}:{a.ayah}</span>
              {a.translation}
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <AyahAudio src={rec.urlFor(n, a.ayah)} label={`${n}:${a.ayah}`} />
              <BookmarkButton targetType="evidence" targetId={a.evidenceId} initial={saved.has(a.evidenceId)} />
              <Link href={`/quran/${n}/${a.ayah}`} className="rounded-full px-2.5 py-1.5 text-xs text-fg-muted hover:bg-surface-muted hover:text-fg">{t("focus")}</Link>
              <ReportButton targetType="evidence" targetId={a.evidenceId} />
            </div>
          </li>
        ))}
      </ol>

      <footer className="mx-auto mt-10 max-w-3xl border-t border-line pt-6 text-xs text-fg-muted">
        <p>{t("attribution")}: {tr?.name}. {tr?.attribution}{trVerified ? "" : ` · ${t("previewPending")}`}</p>
        <p className="mt-1">{rec.attribution}</p>
        <nav className="mt-6 flex justify-between text-sm">
          {n > 1 ? <Link href={`/quran/${n - 1}`} className="inline-flex items-center gap-1 text-fg hover:text-accent-fg"><ChevronLeft className="h-4 w-4 rtl:rotate-180" aria-hidden />{t("prev")}</Link> : <span />}
          {n < 114 ? <Link href={`/quran/${n + 1}`} className="inline-flex items-center gap-1 text-fg hover:text-accent-fg">{t("next")}<ChevronRight className="h-4 w-4 rtl:rotate-180" aria-hidden /></Link> : <span />}
        </nav>
      </footer>
    </Container>
  );
}
