import type { Metadata } from "next";
import { surahName } from "@/lib/surah-names-bn";
import { notFound } from "next/navigation";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { Container, buttonVariants } from "@rasulullah/ui";
import { Link } from "@/i18n/navigation";
import { quran } from "@/server/providers/quran";
import { getEvidence } from "@/server/evidence";
import { EvidenceBlock } from "@/components/evidence/evidence-block";
import { QuranUnavailable } from "@/components/quran/quran-unavailable";
import { getViewer } from "@/server/publishing";

type P = { params: Promise<{ locale: string; surah: string; ayah: string }> };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const { surah, ayah } = await params;
  return { title: `Qur'an ${surah}:${ayah}` };
}

/** Context view: the ayah with the verses around it (spec: "Read context"). */
export default async function AyahPage({ params }: P) {
  const { locale, surah, ayah } = await params;
  setRequestLocale(locale);
  const n = Number(surah), a = Number(ayah);
  const loc = locale === "bn" ? "bn" : "en";
  const viewer = await getViewer();
  const read = await quran.getSurah(n, loc, viewer);
  if (!read.ok && read.reason === "not_found") notFound();
  if (!read.ok) return <QuranUnavailable />;
  const data = read.data;
  if (!Number.isInteger(a) || a < 1 || a > data.meta.verseCount) notFound();
  const t = await getTranslations("quran");
  const focus = data.ayat.find((x) => x.ayah === a);
  const ev = focus ? (await getEvidence([focus.evidenceId], loc, viewer)).get(focus.evidenceId) : undefined;
  if (!focus || !ev) return <QuranUnavailable />;
  const around = data.ayat.filter((x) => x.ayah >= a - 3 && x.ayah <= a + 3);

  return (
    <Container className="py-10 sm:py-14">
      <div className="mx-auto max-w-3xl">
        <p className="text-sm text-fg-muted"><Link href="/quran" className="hover:underline">{t("title")}</Link> / <Link href={`/quran/${n}`} className="hover:underline">{surahName(n, data.meta.transliteration, loc)}</Link> / {a}</p>
        <h1 className="mt-3 text-3xl font-semibold text-fg">{surahName(n, data.meta.transliteration, loc)} · {n}:{a}</h1>
        <div className="mt-8"><EvidenceBlock evidence={ev} kind="quran" /></div>

        <h2 className="mt-12 text-lg font-semibold text-fg">{t("context")}</h2>
        <ol className="mt-4 flex flex-col gap-5">
          {around.map((x) => (
            <li key={x.ayah} className={x.ayah === a ? "rounded-2xl border border-gold-500/60 bg-gold-100/30 p-4" : "px-4"}>
              <p lang="ar" dir="rtl" className="font-arabic text-2xl leading-[2.2] text-fg">{x.arabic}</p>
              <p className="mt-2 text-fg" lang={loc}><span className="me-2 text-sm font-semibold text-accent-fg">{n}:{x.ayah}</span>{x.translation}</p>
            </li>
          ))}
        </ol>
        <Link href={`/quran/${n}#ayah-${a}`} className={buttonVariants({ variant: "secondary", className: "mt-8" })}>{t("readWholeSurah")}</Link>
      </div>
    </Container>
  );
}
