import type { Metadata } from "next";
import { PlaylistSection } from "@/components/learn/playlist-section";
import { surahName } from "@/lib/surah-names-bn";
import { eq } from "drizzle-orm";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { Container } from "@rasulullah/ui";
import { Link } from "@/i18n/navigation";
import { quran } from "@/server/providers/quran";
import { getSession } from "@/server/session";
import { db, schema as s } from "@/server/db";
import { QuranSearchBox } from "@/components/quran/quran-search-box";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "pages.quran" });
  return { title: t("title"), description: t("lead") };
}

export default async function QuranIndex({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("quran");
  const tl = await getTranslations("learn.sections");
  const tp = await getTranslations("pages.quran");
  const surahs = await quran.getSurahs();
  const session = await getSession();
  const [progress] = session ? await db.select().from(s.quranProgress).where(eq(s.quranProgress.userId, session.user.id)) : [];
  const cont = progress ? surahs.find((x) => x.number === progress.lastSurah) : null;

  return (
    <Container className="py-12 sm:py-16">
      <header className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div className="max-w-xl">
          <h1 className="text-4xl font-semibold tracking-tight text-fg sm:text-5xl">{tp("title")}</h1>
          <p className="mt-3 text-lg text-fg-muted">{tp("lead")}</p>
        </div>
        <div className="w-full md:max-w-sm"><QuranSearchBox /></div>
      </header>

      {cont && progress ? (
        <Link href={`/quran/${cont.number}#ayah-${progress.lastAyah}`} className="mt-8 flex items-center justify-between rounded-(--radius-card) bg-green-900 px-6 py-5 text-ivory-50">
          <span>
            <span className="block text-xs uppercase tracking-[0.16em] text-gold-500">{t("continue")}</span>
            <span className="mt-1 block text-lg font-semibold">{surahName(cont.number, cont.transliteration, locale)} · {t("ayah")} {progress.lastAyah}</span>
          </span>
          <span lang="ar" dir="rtl" className="font-arabic text-2xl">{cont.nameArabic}</span>
        </Link>
      ) : null}

      <ul className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {surahs.map((su) => (
          <li key={su.number}>
            <Link href={`/quran/${su.number}`} className="group flex items-center gap-4 rounded-2xl border border-line bg-surface px-4 py-3 transition-colors hover:border-gold-500/60">
              <span className="inline-flex h-10 w-10 shrink-0 rotate-45 items-center justify-center rounded-md border border-gold-500/50 text-sm tabular-nums text-fg">
                <span className="-rotate-45">{su.number}</span>
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate font-medium text-fg">{surahName(su.number, su.transliteration, locale)}</span>
                <span className="block truncate text-sm text-fg-muted">{locale === "bn" ? su.nameBn : su.nameEn} · {su.verseCount} {t("ayat")}</span>
              </span>
              <span lang="ar" dir="rtl" className="font-arabic text-xl text-fg">{su.nameArabic}</span>
            </Link>
          </li>
        ))}
      </ul>
      <PlaylistSection groups={["tafsir", "quran", "reading"]} locale={locale} title={tl("quranTitle")} />
    </Container>
  );
}
