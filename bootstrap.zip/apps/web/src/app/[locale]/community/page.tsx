import type { Metadata } from "next";
import { getFormatter, getTranslations, setRequestLocale } from "next-intl/server";
import { Container } from "@rasulullah/ui";
import { Link } from "@/i18n/navigation";
import { getSession } from "@/server/session";
import { listPosts } from "@/server/community";
import { Composer } from "@/components/community/composer";
import { PostActions } from "@/components/community/post-actions";
import { Comments } from "@/components/community/comments";
import { POST_KINDS } from "@/server/community-rules";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "community" });
  return { title: t("title"), description: t("lead") };
}

export default async function CommunityPage({ params, searchParams }: { params: Promise<{ locale: string }>; searchParams: Promise<{ before?: string; kind?: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("community");
  const fmt = await getFormatter();
  const session = await getSession();
  const sp = await searchParams;
  const beforeRaw = sp.before;
  const kind = (POST_KINDS as readonly string[]).includes(sp.kind ?? "") ? sp.kind : undefined;
  const before = beforeRaw && !Number.isNaN(Date.parse(beforeRaw)) ? new Date(beforeRaw) : undefined;
  const posts = await listPosts({ userId: session?.user.id ?? null, before, limit: 20, kind });
  const last = posts.at(-1);

  return (
    <Container className="py-12">
      <div className="mx-auto max-w-2xl">
        <h1 className="text-4xl font-semibold tracking-tight text-fg">{t("title")}</h1>
        <p className="mt-3 text-lg text-fg-muted">{t("lead")}</p>
        <p className="mt-4 rounded-xl border border-gold-500/40 bg-gold-500/5 p-3 text-sm text-fg">{t("disclaimer")}</p>

        <nav className="mt-6 flex flex-wrap gap-2 text-sm">
          <Link href="/community" className={`rounded-full border px-3 py-1 ${!kind ? "border-green-900 bg-green-900 text-ivory-50" : "border-line text-fg-muted"}`}>{t("all")}</Link>
          {POST_KINDS.map((k) => <Link key={k} href={`/community?kind=${k}`} className={`rounded-full border px-3 py-1 ${kind === k ? "border-green-900 bg-green-900 text-ivory-50" : "border-line text-fg-muted"}`}>{t(`kinds.${k}`)}</Link>)}
        </nav>
        <div className="mt-6">
          {session ? <Composer initialKind={kind} /> : (
            <p className="rounded-2xl border border-line bg-surface p-4 text-fg-muted">
              {t("signInToPost")} <Link href="/auth/signin" className="font-medium text-fg underline">{t("signIn")}</Link> · <Link href="/auth/signup" className="font-medium text-fg underline">{t("createAccount")}</Link>
            </p>
          )}
        </div>

        <ol className="mt-8 flex flex-col gap-4">
          {posts.map((p) => (
            <li key={p.id} className="rounded-2xl border border-line bg-surface p-5">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <span className="font-semibold text-fg">{p.author}</span>
                <span className="rounded-full bg-surface-muted px-2 py-0.5 text-xs text-fg-muted">{t(`kinds.${p.kind}`)}</span>
                <time className="text-xs text-fg-muted" dateTime={p.createdAt.toISOString()}>{fmt.relativeTime(p.createdAt)}</time>
                {p.status === "held" ? <span className="rounded-full bg-gold-500/15 px-2 py-0.5 text-xs text-gold-700">{t("awaitingReview")}</span> : null}
              </div>
              <p className="mt-3 whitespace-pre-wrap break-words text-fg">{p.body}</p>
              <PostActions id={p.id} counts={p.reactions} reacted={p.reacted} mine={p.mine} signedIn={!!session} published={p.status === "published"} />
              {p.status === "published" ? <Comments postId={p.id} comments={p.comments} signedIn={!!session} /> : null}
            </li>
          ))}
        </ol>
        {!posts.length ? <p className="mt-10 text-center text-fg-muted">{t("empty")}</p> : null}
        {posts.length === 20 && last ? (
          <div className="mt-8 text-center"><Link href={`/community?${kind ? `kind=${kind}&` : ""}before=${encodeURIComponent(last.createdAt.toISOString())}`} className="rounded-full border border-line px-5 py-2 text-sm text-fg hover:border-gold-500/60">{t("older")}</Link></div>
        ) : null}
      </div>
    </Container>
  );
}
