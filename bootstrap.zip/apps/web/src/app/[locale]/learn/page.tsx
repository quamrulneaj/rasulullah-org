import type { Metadata } from "next";
import { surahName } from "@/lib/surah-names-bn";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { Container } from "@rasulullah/ui";
import { Link } from "@/i18n/navigation";
import { evidenceIdsByRefs, getEvidence } from "@/server/evidence";
import { getViewer } from "@/server/publishing";
import { quran } from "@/server/providers/quran";
import { EvidenceBlock } from "@/components/evidence/evidence-block";
import { PlaylistEmbed } from "@/components/learn/playlist-embed";
import { Speak } from "@/components/learn/speak";
import { ALPHABET, NAWAWI_COUNT, PLAYLISTS, PRACTICE_SURAHS, QURAN_BASICS, nawawiOfTheDay } from "@/lib/learn-data";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "pages.learn" });
  return { title: t("title"), description: t("lead") };
}

export default async function LearnPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const L = locale === "bn" ? "bn" : "en";
  const t = await getTranslations("learn");
  const tp = await getTranslations("pages.learn");
  const viewer = await getViewer();

  const n = nawawiOfTheDay();
  const ref = `hadith:nawawi:${n}`;
  const id = (await evidenceIdsByRefs([ref])).get(ref);
  const todays = id ? (await getEvidence([id], L, viewer)).get(id) ?? null : null;

  const surahs = (await quran.getSurahs()).filter((s) => PRACTICE_SURAHS.includes(s.number));
  const practice = PRACTICE_SURAHS.map((n) => surahs.find((s) => s.number === n)).filter((s) => !!s);

  const groups = (["reading", "quran", "tafsir", "seerah", "latest"] as const).map((g) => ({ g, items: PLAYLISTS.filter((p) => p.group === g) }));

  return (
    <Container className="py-12 sm:py-16">
      <header className="max-w-2xl">
        <h1 className="text-4xl font-semibold tracking-tight text-fg sm:text-5xl">{tp("title")}</h1>
        <p className="mt-3 text-lg text-fg-muted">{tp("lead")}</p>
        <nav className="mt-6 flex flex-wrap gap-2 text-sm">
          {(["basics", "hadith", "videos"] as const).map((k) => (
            <a key={k} href={`#${k}`} className="rounded-full border border-line px-4 py-1.5 text-fg hover:border-gold-500/60">{t(`nav.${k}`)}</a>
          ))}
        </nav>
      </header>

      {/* ── Qur'an basics ── */}
      <section id="basics" className="mt-14 scroll-mt-24">
        <h2 className="text-2xl font-semibold text-fg">{t("basics.title")}</h2>
        <p className="mt-2 max-w-2xl text-fg-muted">{t("basics.lead")}</p>
        <p className="mt-1 max-w-2xl text-xs text-fg-muted">{t("voiceNote")}</p>
        <ol className="mt-6 space-y-4">
          {QURAN_BASICS.map((lesson, i) => (
            <li key={lesson.id}>
              <details className="group rounded-2xl border border-line bg-surface p-5" open={i === 0}>
                <summary className="cursor-pointer list-none text-lg font-semibold text-fg">{lesson.title[L]}</summary>
                <p className="mt-3 text-fg-muted">{lesson.body[L]}</p>
                {lesson.letters ? (
                  <ul className="mt-5 grid grid-cols-4 gap-2 sm:grid-cols-7">
                    {ALPHABET.map((x) => (
                      <li key={x.name + x.ch} className="flex flex-col items-center rounded-xl border border-line px-2 py-3 text-center">
                        <span lang="ar" dir="rtl" className="font-arabic text-3xl text-fg">{x.ch}</span>
                        <span className="mt-1 text-xs font-medium text-fg">{L === "bn" ? x.bn : x.name}</span>
                        <span className="text-[11px] text-fg-muted">{x.sound}</span>
                        <Speak text={x.spoken} label={`${t("listen")} ${L === "bn" ? x.bn : x.name}`} noVoice={t("noVoice")} />
                      </li>
                    ))}
                  </ul>
                ) : null}
                {lesson.examples ? (
                  <ul className="mt-5 flex flex-wrap gap-3">
                    {lesson.examples.map((x) => (
                      <li key={x.say} className="flex min-w-20 flex-col items-center rounded-xl border border-line px-4 py-3">
                        <span lang="ar" dir="rtl" className="font-arabic text-3xl text-fg">{x.ch}</span>
                        <span className="mt-1 text-sm text-fg-muted">{x.say}</span>
                        <Speak text={x.ch} label={`${t("listen")} ${x.say}`} noVoice={t("noVoice")} />
                      </li>
                    ))}
                  </ul>
                ) : null}
              </details>
            </li>
          ))}
          <li className="rounded-2xl border border-line bg-surface p-5">
            <p className="text-lg font-semibold text-fg">{t("basics.practiceTitle")}</p>
            <p className="mt-2 text-fg-muted">{t("basics.practiceLead")}</p>
            <ul className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {practice.map((s) => (
                <li key={s!.number}>
                  <Link href={`/quran/${s!.number}`} className="flex items-center justify-between rounded-xl border border-line px-4 py-3 hover:border-gold-500/60">
                    <span className="text-fg">{s!.number}. {surahName(s!.number, s!.transliteration, L)}</span>
                    <span lang="ar" dir="rtl" className="font-arabic text-xl text-fg">{s!.nameArabic}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </li>
        </ol>
      </section>

      {/* ── Hadith ── */}
      <section id="hadith" className="mt-16 scroll-mt-24">
        <h2 className="text-2xl font-semibold text-fg">{t("hadith.title")}</h2>
        <p className="mt-2 max-w-2xl text-fg-muted">{t("hadith.lead")}</p>
        {todays ? (
          <div className="mt-6">
            <p className="mb-3 text-sm font-medium uppercase tracking-[0.14em] text-gold-700">{t("hadith.today", { n })}</p>
            <EvidenceBlock evidence={todays} kind="prophetic" />
          </div>
        ) : null}
        <p className="mt-8 font-medium text-fg">{t("hadith.all")}</p>
        <ul className="mt-3 grid grid-cols-6 gap-2 sm:grid-cols-10 lg:grid-cols-14">
          {Array.from({ length: NAWAWI_COUNT }, (_, i) => i + 1).map((k) => (
            <li key={k}>
              <Link href={`/hadith/nawawi/${k}`} className={`flex h-10 items-center justify-center rounded-lg border text-sm ${k === n ? "border-gold-500 bg-gold-500/10 font-semibold text-fg" : "border-line text-fg-muted hover:text-fg"}`}>{k}</Link>
            </li>
          ))}
        </ul>
      </section>

      {/* ── Video courses ── */}
      <section id="videos" className="mt-16 scroll-mt-24">
        <h2 className="text-2xl font-semibold text-fg">{t("videos.title")}</h2>
        <p className="mt-2 max-w-2xl text-fg-muted">{t("videos.lead")}</p>
        {groups.map(({ g, items }) => (
          <div key={g} className="mt-8">
            <h3 className="text-lg font-semibold text-fg">{t(`videos.groups.${g}`)}</h3>
            <div className="mt-4 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {items.map((p) => (
                <PlaylistEmbed key={p.id} id={p.id} title={p.title} channel={p.channel} channelUrl={p.channelUrl} playLabel={t("videos.play")} openLabel={t("videos.open")} captionLang={L === "bn" && p.lang !== "bn" ? "bn" : undefined} />
              ))}
            </div>
          </div>
        ))}
        <p className="mt-6 text-sm text-fg-muted">{t("videos.note")}</p>
      </section>
    </Container>
  );
}
