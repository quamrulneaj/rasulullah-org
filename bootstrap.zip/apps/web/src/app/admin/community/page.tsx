import { desc, eq } from "drizzle-orm";
import { db, schema as s } from "@/server/db";
import { adminPage } from "@/server/admin-guard";
import { moderateComment, moderatePost } from "@/server/actions/community";
import { ActionButton } from "@/components/admin/action-button";
import { PageTitle, Pill, Table, statusTone } from "@/components/admin/ui";

export const metadata = { title: "Community" };
const STATUSES = ["held", "hidden", "published", "removed"] as const;

export default async function CommunityAdmin({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  await adminPage("handleReports");
  const q = (await searchParams).status;
  const status = (STATUSES as readonly string[]).includes(q ?? "") ? (q as (typeof STATUSES)[number]) : "held";
  const rows = await db
    .select({ id: s.communityPosts.id, kind: s.communityPosts.kind, body: s.communityPosts.body, status: s.communityPosts.status, heldReason: s.communityPosts.heldReason, reports: s.communityPosts.reportCount, createdAt: s.communityPosts.createdAt, author: s.user.name, email: s.user.email })
    .from(s.communityPosts).innerJoin(s.user, eq(s.user.id, s.communityPosts.userId))
    .where(eq(s.communityPosts.status, status)).orderBy(desc(s.communityPosts.createdAt)).limit(100);
  const comments = await db
    .select({ id: s.communityComments.id, body: s.communityComments.body, status: s.communityComments.status, heldReason: s.communityComments.heldReason, reports: s.communityComments.reportCount, createdAt: s.communityComments.createdAt, author: s.user.name, email: s.user.email })
    .from(s.communityComments).innerJoin(s.user, eq(s.user.id, s.communityComments.userId))
    .where(eq(s.communityComments.status, status)).orderBy(desc(s.communityComments.createdAt)).limit(100);
  return (
    <div className="max-w-6xl">
      <PageTitle title="Community posts" />
      <p className="mb-4 max-w-3xl text-sm text-fg-muted">
        Held posts quote or cite religious sources, contain links/contact details, ask fiqh questions or use crisis language. Publish only personal reflections;
        check any quoted hadith or ayah against the site&apos;s verified sources first. Posts with 3+ reports are hidden automatically.
      </p>
      <nav className="mb-4 flex gap-2 text-sm">{STATUSES.map((x) => <a key={x} href={`?status=${x}`} className={`rounded-full border px-3 py-1 ${x === status ? "border-green-900 bg-green-900 text-ivory-50" : "border-line"}`}>{x}</a>)}</nav>
      <Table head={["When", "Author", "Post", "Why held", "Reports", "Status", ""]}>
        {rows.map((r) => (
          <tr key={r.id} className="align-top">
            <td className="px-3 py-2 text-xs">{r.createdAt.toISOString().slice(0, 16)}</td>
            <td className="px-3 py-2 text-xs">{r.author}<br /><span className="text-fg-muted">{r.email}</span></td>
            <td className="max-w-md whitespace-pre-wrap px-3 py-2 text-sm"><span className="text-xs uppercase text-fg-muted">{r.kind}</span><br />{r.body}</td>
            <td className="px-3 py-2 text-xs">{r.heldReason ?? "—"}</td>
            <td className="px-3 py-2 text-xs">{r.reports}</td>
            <td className="px-3 py-2"><Pill tone={statusTone(r.status)}>{r.status}</Pill></td>
            <td className="px-3 py-2"><div className="flex flex-col gap-1">
              {r.status !== "published" ? <ActionButton action={moderatePost.bind(null, r.id, "published")} label="Publish" tone="primary" /> : null}
              {r.status !== "hidden" ? <ActionButton action={moderatePost.bind(null, r.id, "hidden")} label="Hide" /> : null}
              {r.status !== "removed" ? <ActionButton action={moderatePost.bind(null, r.id, "removed")} label="Remove" tone="danger" /> : null}
            </div></td>
          </tr>
        ))}
      </Table>
      <h2 className="mb-3 mt-10 text-lg font-semibold">Comments ({status})</h2>
      <Table head={["When", "Author", "Comment", "Why held", "Reports", ""]}>
        {comments.map((c) => (
          <tr key={c.id} className="align-top">
            <td className="px-3 py-2 text-xs">{c.createdAt.toISOString().slice(0, 16)}</td>
            <td className="px-3 py-2 text-xs">{c.author}<br /><span className="text-fg-muted">{c.email}</span></td>
            <td className="max-w-md whitespace-pre-wrap px-3 py-2 text-sm">{c.body}</td>
            <td className="px-3 py-2 text-xs">{c.heldReason ?? "—"}</td>
            <td className="px-3 py-2 text-xs">{c.reports}</td>
            <td className="px-3 py-2"><div className="flex flex-col gap-1">
              {c.status !== "published" ? <ActionButton action={moderateComment.bind(null, c.id, "published")} label="Publish" tone="primary" /> : null}
              {c.status !== "hidden" ? <ActionButton action={moderateComment.bind(null, c.id, "hidden")} label="Hide" /> : null}
              {c.status !== "removed" ? <ActionButton action={moderateComment.bind(null, c.id, "removed")} label="Remove" tone="danger" /> : null}
            </div></td>
          </tr>
        ))}
      </Table>
    </div>
  );
}
