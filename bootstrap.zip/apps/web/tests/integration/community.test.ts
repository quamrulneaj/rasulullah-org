import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { inArray } from "drizzle-orm";
import { db, schema as s } from "@/server/db";
import { listPosts, salawatStats } from "@/server/community";
import { hasDb } from "./helpers";

describe.skipIf(!hasDb)("community feed visibility", () => {
  const a = `test-a-${Date.now()}`, b = `test-b-${Date.now()}`;
  beforeAll(async () => {
    await db.insert(s.user).values([{ id: a, name: "Amina Test", email: `${a}@example.test` }, { id: b, name: "Bilal Test", email: `${b}@example.test` }]);
    await db.insert(s.communityPosts).values([
      { userId: a, kind: "reflection", body: "published by A", status: "published" },
      { userId: a, kind: "reflection", body: "held by A", status: "held", heldReason: "religious_citation" },
      { userId: b, kind: "reflection", body: "held by B", status: "held" },
      { userId: b, kind: "reflection", body: "hidden by B", status: "hidden" },
    ]);
  });
  afterAll(async () => { await db.delete(s.user).where(inArray(s.user.id, [a, b])); });

  const mine = (posts: { body: string }[]) => posts.map((p) => p.body).filter((x) => / by [AB]$/.test(x)).sort();
  it("public sees only published posts, first name only", async () => {
    const p = await listPosts({ userId: null, limit: 100 });
    expect(mine(p)).toEqual(["published by A"]);
    expect(p.find((x) => x.body === "published by A")!.author).toBe("Amina");
  });
  it("an author also sees their own held post; never others' held or hidden posts", async () => {
    expect(mine(await listPosts({ userId: a, limit: 100 }))).toEqual(["held by A", "published by A"]);
    expect(mine(await listPosts({ userId: b, limit: 100 }))).toEqual(["held by B", "published by A"]);
  });

  it("salawat: today's community total and the member's own count", async () => {
    const before = await salawatStats(a);
    const day = new Date().toISOString().slice(0, 10);
    await db.insert(s.salawatLog).values([{ userId: a, day, count: 33 }, { userId: b, day, count: 100 }]);
    const after = await salawatStats(a);
    expect(after.today - before.today).toBe(133);
    expect(after.mine).toBe(33);
    expect(after.people - before.people).toBe(2);
  });

  it("comments: public sees published comments; the author also sees their own held comment", async () => {
    const [post] = await db.select({ id: s.communityPosts.id }).from(s.communityPosts).where(inArray(s.communityPosts.userId, [a])).limit(1);
    const pub = (await listPosts({ userId: null, limit: 100 })).find((p) => p.body === "published by A")!;
    await db.insert(s.communityComments).values([{ postId: pub.id, userId: b, body: "comment ok", status: "published" }, { postId: pub.id, userId: b, body: "comment held", status: "held" }]);
    expect((await listPosts({ userId: null, limit: 100 })).find((p) => p.id === pub.id)!.comments.map((c) => c.body)).toEqual(["comment ok"]);
    expect((await listPosts({ userId: b, limit: 100 })).find((p) => p.id === pub.id)!.comments.map((c) => c.body).sort()).toEqual(["comment held", "comment ok"]);
    expect(post).toBeTruthy();
  });
});
