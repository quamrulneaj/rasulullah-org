/**
 * Applies the owner's written review decision (src/server/sources/owner-decisions.ts) after seeding.
 * Idempotent and conservative: only still-pending, seed-owned rows are approved; each approval is logged.
 */
import { and, eq, inArray, isNull } from "drizzle-orm";
import { createDb, databaseUrl } from "../src/server/db/client";
import * as s from "../src/server/db/schema";
import { CHECKED_CRISIS_NUMBERS, OWNER_APPROVED_SEERAH_V1, OWNER_APPROVED_SEERAH_V2, OWNER_APPROVED_SEERAH_V3, OWNER_REVIEW_DECISION as D, OWNER_VERIFIED_EDITORIAL_KEYS } from "../src/server/sources/owner-decisions";
import { CARDS } from "./seed/editorial";

const { db, pool } = createDb(databaseUrl(true), { max: 2 });
const log = (targetType: string, ids: (string | number)[]) =>
  ids.length ? db.insert(s.scholarReviews).values(ids.map((id) => ({ targetType, targetId: String(id), reviewerId: D.by, decision: "approve", comment: D.comment }))) : null;

// Editorial Seerah source (the site's own work) — only if nobody has decided on it yet.
for (const key of OWNER_VERIFIED_EDITORIAL_KEYS) {
  const [cur] = await db.select().from(s.sources).where(eq(s.sources.key, key));
  if (cur && cur.licenseStatus === "pending" && cur.status === "pending" && !cur.verifiedAt) {
    await db.update(s.sources).set({ licenseStatus: "verified", status: "verified", verifiedBy: D.by, verifiedAt: D.at, updatedAt: new Date() }).where(eq(s.sources.id, cur.id));
    await db.insert(s.auditLogs).values({ actorId: "owner-decision", action: "source.registry", targetType: "source", targetId: key, meta: { from: "pending", to: "verified", by: D.by } });
  }
}

// Topic → evidence mappings seeded by the editor.
const maps = await db.update(s.topicEvidence).set({ reviewStatus: "approved", updatedAt: new Date() })
  .where(and(eq(s.topicEvidence.reviewStatus, "pending_review"), eq(s.topicEvidence.assignedBy, "seed:editor"))).returning({ id: s.topicEvidence.id });
await log("topic_evidence", maps.map((m) => m.id));

// Seeded editorial cards (matched by their exact seed text).
const cards = await db.update(s.editorialCards).set({ reviewStatus: "approved", updatedAt: new Date() })
  .where(and(eq(s.editorialCards.reviewStatus, "pending_review"), inArray(s.editorialCards.textEn, CARDS.map((c) => c.en)))).returning({ id: s.editorialCards.id });
await log("editorial_card", cards.map((c) => c.id));

// Seerah timeline v1 events and their evidence rows.
const events = await db.update(s.seerahEvents).set({ reviewStatus: "approved", updatedAt: new Date() })
  .where(and(eq(s.seerahEvents.reviewStatus, "pending_review"), eq(s.seerahEvents.authorId, "seed:editor"), inArray(s.seerahEvents.slug, [...OWNER_APPROVED_SEERAH_V1, ...OWNER_APPROVED_SEERAH_V2, ...OWNER_APPROVED_SEERAH_V3])))
  .returning({ id: s.seerahEvents.id, evidenceId: s.seerahEvents.evidenceId });
const evIds = events.map((e) => e.evidenceId).filter((x): x is string => !!x);
if (evIds.length) await db.update(s.evidence).set({ reviewStatus: "approved" }).where(and(inArray(s.evidence.id, evIds), eq(s.evidence.reviewStatus, "pending_review")));
await log("seerah_event", events.map((e) => e.id));

// Crisis resources whose numbers were checked against public sources.
let crisis = 0;
for (const [country, phone] of CHECKED_CRISIS_NUMBERS) {
  const r = await db.update(s.crisisResources).set({ verifiedAt: D.at, verifiedBy: D.by })
    .where(and(eq(s.crisisResources.countryCode, country), phone ? eq(s.crisisResources.phone, phone) : isNull(s.crisisResources.phone), isNull(s.crisisResources.verifiedAt)))
    .returning({ id: s.crisisResources.id });
  crisis += r.length;
}

console.log(`✓ owner review decision applied: ${maps.length} mappings, ${cards.length} cards, ${events.length} Seerah events, ${crisis} crisis resources`);
await pool.end();
