/**
 * Seerah timeline v3 (2026-10-01) — more of his life ﷺ and of the Companions' love for him.
 * Same rules as v1/v2: editorial metadata only; the story is the linked Sahih al-Bukhari narration, each number
 * located by searching the ingested text and read before inclusion. Seeded `pending_review`; approved by the
 * owner's standing instruction (OWNER_APPROVED_SEERAH_V3 in owner-decisions.ts).
 */
import type { TimelineEvent } from "./seerah-timeline";

const RM = "Safiur Rahman Mubarakpuri, Ar-Raheeq al-Makhtum (further reading)";
type L = TimelineEvent["links"][number];
const q = (s: number, a: number, b = a): L[] => Array.from({ length: b - a + 1 }, (_, i) => [`quran:${s}:${a + i}`, "quran_link"]);
const h = (...ns: number[]): L[] => ns.map((n) => [`hadith:bukhari:${n}`, "hadith_link"]);
const B = (label: string): [string, boolean][] => [[label, true], [RM, false]];

export const TIMELINE_V3: TimelineEvent[] = [
  { slug: "remembering-khadijah", period: "persecution", date: "c. 619 CE (the Year of Sorrow)", certainty: "approximate", location: "Makkah", people: ["Khadijah (RA)", "Aisha (RA)"], themes: ["marriage", "grief", "shukr"],
    en: { title: "He never forgot Khadijah", summary: "Aisha (RA) narrates in Sahih al-Bukhari that the Prophet ﷺ mentioned Khadijah (RA) so often, years after her death, that she felt jealous of her — he would even send gifts to Khadijah's friends.", lessons: ["Faithfulness continues after death.", "Gratitude to those who stood by us in hard times is part of noble character."] },
    bn: { title: "খাদিজা (রাঃ)-কে তিনি কখনো ভোলেননি", summary: "সহিহ বুখারিতে আয়েশা (রাঃ) বর্ণনা করেন, খাদিজা (রাঃ)-এর মৃত্যুর বহু বছর পরও নবী ﷺ এত বেশি তাঁর কথা বলতেন যে আয়েশা (রাঃ)-এর ঈর্ষা হতো — এমনকি তিনি খাদিজার বান্ধবীদের কাছে উপহার পাঠাতেন।", lessons: ["বিশ্বস্ততা মৃত্যুর পরও থাকে।", "কঠিন সময়ে যারা পাশে ছিল তাদের প্রতি কৃতজ্ঞতা মহৎ চরিত্রের অংশ।"] },
    links: h(3818), bib: B("Sahih al-Bukhari 3818 (Aisha)") },

  { slug: "abu-dharr-accepts-islam", period: "early-makkah", date: "Early Makkan period", certainty: "approximate", location: "Makkah", people: ["Abu Dharr (RA)", "'Ali (RA)"], themes: ["purpose-of-life", "youth", "sabr"],
    en: { title: "Abu Dharr searches for the truth", summary: "Ibn 'Abbas (RA) narrates in Sahih al-Bukhari how Abu Dharr (RA) travelled to Makkah to find the Prophet ﷺ, was quietly guided to him by 'Ali (RA), accepted Islam and then declared it openly at the Ka'bah despite being beaten.", lessons: ["Sincere searching is met with guidance.", "Courage for the truth can cost — and it is worth it."] },
    bn: { title: "সত্যের খোঁজে আবু যর", summary: "সহিহ বুখারিতে ইবনে আব্বাস (রাঃ) বর্ণনা করেন, আবু যর (রাঃ) নবী ﷺ-কে খুঁজতে মক্কায় আসেন, আলী (রাঃ) গোপনে তাঁকে পথ দেখান, তিনি ইসলাম গ্রহণ করেন, তারপর মার খাওয়া সত্ত্বেও কাবার সামনে প্রকাশ্যে তা ঘোষণা করেন।", lessons: ["আন্তরিক অনুসন্ধানকারী হিদায়াত পায়।", "সত্যের জন্য সাহসের মূল্য দিতে হয় — আর তা মূল্যবান।"] },
    links: h(3861), bib: B("Sahih al-Bukhari 3861 (Ibn 'Abbas)") },

  { slug: "umar-accepts-islam", period: "persecution", date: "Makkan period", certainty: "approximate", location: "Makkah", people: ["'Umar ibn al-Khattab (RA)", "Ibn 'Umar (RA)"], themes: ["fear", "tawakkul", "community"],
    en: { title: "'Umar in fear after accepting Islam", summary: "'Abdullah ibn 'Umar (RA) narrates in Sahih al-Bukhari how his father, newly Muslim, sat at home in fear of Quraysh until Al-'As ibn Wa'il offered him protection and turned the crowd away.", lessons: ["Even the strongest feel fear; Allah sends protection through unexpected people."] },
    bn: { title: "ইসলাম গ্রহণের পর উমরের ভয়", summary: "সহিহ বুখারিতে আব্দুল্লাহ ইবনে উমর (রাঃ) বর্ণনা করেন, সদ্য ইসলাম গ্রহণ করা তাঁর পিতা কুরাইশের ভয়ে ঘরে বসে ছিলেন, তখন আস ইবনে ওয়াইল তাঁকে আশ্রয় দেন এবং ভিড়কে ফিরিয়ে দেন।", lessons: ["সবচেয়ে শক্তিশালী মানুষও ভয় পায়; আল্লাহ অপ্রত্যাশিত মানুষের মাধ্যমে রক্ষা করেন।"] },
    links: h(3864), bib: B("Sahih al-Bukhari 3864 ('Abdullah ibn 'Umar)") },

  { slug: "bilal-freed-by-abu-bakr", period: "persecution", date: "Makkan period", certainty: "approximate", location: "Makkah", people: ["Bilal (RA)", "Abu Bakr (RA)", "'Umar (RA)"], themes: ["charity", "justice", "community"],
    en: { title: "\"Our master freed our master\"", summary: "Jabir (RA) narrates in Sahih al-Bukhari that 'Umar (RA) used to say: Abu Bakr is our master, and he freed our master — meaning Bilal (RA), the enslaved man Abu Bakr bought and set free.", lessons: ["In Islam, honour is by taqwa, not lineage or wealth.", "Spend your wealth to free people from oppression."] },
    bn: { title: "\"আমাদের নেতা আমাদের নেতাকে মুক্ত করেছেন\"", summary: "সহিহ বুখারিতে জাবির (রাঃ) বর্ণনা করেন, উমর (রাঃ) বলতেন: আবু বকর আমাদের নেতা, আর তিনি আমাদের নেতাকে মুক্ত করেছেন — অর্থাৎ বিলাল (রাঃ)-কে, যাঁকে আবু বকর কিনে মুক্ত করে দিয়েছিলেন।", lessons: ["ইসলামে মর্যাদা তাকওয়ায়, বংশ বা সম্পদে নয়।", "সম্পদ ব্যয় করুন মানুষকে জুলুম থেকে মুক্ত করতে।"] },
    links: h(3754), bib: B("Sahih al-Bukhari 3754 (Jabir)") },

  { slug: "the-first-adhan", period: "madinah", date: "1 AH", certainty: "approximate", location: "Madinah", people: ["Bilal (RA)", "'Umar (RA)", "Ibn 'Umar (RA)"], themes: ["salah", "community"],
    en: { title: "Bilal calls the first adhan", summary: "Ibn 'Umar (RA) narrates in Sahih al-Bukhari how the Muslims in Madinah discussed how to gather for prayer — a bell, a horn — until 'Umar (RA) suggested a man call the people, and the Prophet ﷺ ordered Bilal (RA) to get up and call the adhan.", lessons: ["The call to prayer began with a community consulting together.", "Bilal's voice, once silenced in Makkah, called the whole city to Allah."] },
    bn: { title: "বিলালের প্রথম আজান", summary: "সহিহ বুখারিতে ইবনে উমর (রাঃ) বর্ণনা করেন, মদিনায় মুসলমানরা নামাজে একত্র হওয়ার উপায় নিয়ে পরামর্শ করছিলেন — ঘণ্টা, শিঙা — তখন উমর (রাঃ) প্রস্তাব দিলেন একজন মানুষ ডাকবে, আর নবী ﷺ বিলাল (রাঃ)-কে উঠে আজান দিতে আদেশ দিলেন।", lessons: ["আজানের শুরু হয়েছিল সবার পরামর্শ থেকে।", "মক্কায় যাঁর কণ্ঠ রুদ্ধ করা হয়েছিল, সেই বিলালই পুরো শহরকে আল্লাহর দিকে ডাকলেন।"] },
    links: h(604), bib: B("Sahih al-Bukhari 604 (Ibn 'Umar)") },

  { slug: "change-of-qibla", period: "madinah", date: "c. 2 AH", certainty: "approximate", location: "Madinah", people: ["Al-Bara' ibn 'Azib (RA)"], themes: ["dua", "salah", "tawakkul"],
    en: { title: "The Qiblah turns to the Ka'bah", summary: "Al-Bara' (RA) narrates in Sahih al-Bukhari that the Prophet ﷺ prayed towards Jerusalem for sixteen or seventeen months while longing to face the Ka'bah, until Allah revealed 2:144 — \"We have seen the turning of your face towards the heaven.\"", lessons: ["Allah sees the longing we do not say aloud.", "Wait with hope; the answer comes in its time."] },
    bn: { title: "কিবলা কাবার দিকে ফিরল", summary: "সহিহ বুখারিতে বারা (রাঃ) বর্ণনা করেন, নবী ﷺ ষোল বা সতেরো মাস বায়তুল মাকদিসের দিকে নামাজ পড়েছেন, আর মনে মনে কাবার দিকে ফিরতে চাইতেন — অবশেষে আল্লাহ ২:১৪৪ নাযিল করলেন: \"আমি তোমার বারবার আকাশের দিকে মুখ ফেরানো দেখছি।\"", lessons: ["মুখে না বলা আকাঙ্ক্ষাও আল্লাহ দেখেন।", "আশা নিয়ে অপেক্ষা করুন; উত্তর আসে তার নির্ধারিত সময়ে।"] },
    links: [...q(2, 144), ...h(399)], bib: B("Sahih al-Bukhari 399 (Al-Bara')") },

  { slug: "anas-ibn-an-nadr", period: "madinah", date: "Shawwal, 3 AH", certainty: "established", location: "Mount Uhud, near Madinah", people: ["Anas ibn an-Nadr (RA)", "Anas (RA)"], themes: ["sabr", "akhirah", "youth"],
    en: { title: "Anas ibn an-Nadr at Uhud", summary: "Anas (RA) narrates in Sahih al-Bukhari that his uncle, who had missed Badr, vowed Allah would see what he would do; at Uhud he advanced saying he smelt the fragrance of Paradise beyond Uhud, and was found with more than eighty wounds. Verse 33:23 speaks of such men.", lessons: ["A missed chance can become a sincere promise to Allah.", "Some loved Allah's cause more than their own lives."] },
    bn: { title: "উহুদে আনাস ইবনে নাদর", summary: "সহিহ বুখারিতে আনাস (রাঃ) বর্ণনা করেন, বদরে অংশ নিতে না পারা তাঁর চাচা বলেছিলেন, আল্লাহ দেখবেন তিনি কী করেন; উহুদে তিনি এগিয়ে গিয়ে বললেন উহুদের ওপার থেকে তিনি জান্নাতের সুগন্ধ পাচ্ছেন, পরে তাঁকে আশিটিরও বেশি আঘাতসহ পাওয়া যায়। আয়াত ৩৩:২৩ এমন মানুষদের কথা বলে।", lessons: ["হারানো সুযোগ আল্লাহর কাছে আন্তরিক প্রতিজ্ঞায় পরিণত হতে পারে।", "কেউ কেউ আল্লাহর পথকে নিজের জীবনের চেয়েও বেশি ভালোবেসেছেন।"] },
    links: [...q(33, 23), ...h(2805)], bib: B("Sahih al-Bukhari 2805 (Anas)") },

  { slug: "hamza-and-wahshi", period: "madinah", date: "After the conquest of Makkah", certainty: "approximate", location: "Madinah", people: ["Wahshi", "Hamza (RA)"], themes: ["forgiveness", "grief", "tawbah"],
    en: { title: "Wahshi comes to the Prophet ﷺ", summary: "In Sahih al-Bukhari, Wahshi himself recounts killing Hamza (RA) at Uhud, later accepting Islam, and the Prophet ﷺ — who had lost his beloved uncle — accepting him while asking him to keep his face from him.", lessons: ["Islam accepted even the man who killed the Prophet's uncle.", "Forgiving does not mean the pain disappears — he ﷺ was human, and still forgave."] },
    bn: { title: "ওয়াহশি নবী ﷺ-এর কাছে", summary: "সহিহ বুখারিতে ওয়াহশি নিজে বর্ণনা করেন, উহুদে তিনি হামযা (রাঃ)-কে হত্যা করেছিলেন, পরে ইসলাম গ্রহণ করেন; প্রিয় চাচাকে হারানো নবী ﷺ তাঁকে গ্রহণ করেন, তবে বলেন তিনি যেন সামনে না আসেন।", lessons: ["নবীর চাচার হত্যাকারীকেও ইসলাম গ্রহণ করেছে।", "ক্ষমা মানে ব্যথা মুছে যাওয়া নয় — তিনি ﷺ মানুষ ছিলেন, তবুও ক্ষমা করেছেন।"] },
    links: h(4072), bib: B("Sahih al-Bukhari 4072 (Wahshi, via Ja'far ibn 'Amr)") },

  { slug: "sad-ibn-muadh", period: "madinah", date: "5 AH", certainty: "approximate", location: "Madinah", people: ["Sa'd ibn Mu'adh (RA)", "Jabir ibn 'Abdullah (RA)"], themes: ["death-awareness", "akhirah", "leadership"],
    en: { title: "The Throne shook for Sa'd ibn Mu'adh", summary: "Jabir (RA) narrates in Sahih al-Bukhari that he heard the Prophet ﷺ say the Throne of Allah shook at the death of Sa'd ibn Mu'adh (RA).", lessons: ["A life given to Allah is honoured beyond this world."] },
    bn: { title: "সা'দ ইবনে মুআজের জন্য আরশ কেঁপে উঠল", summary: "সহিহ বুখারিতে জাবির (রাঃ) বর্ণনা করেন, তিনি নবী ﷺ-কে বলতে শুনেছেন: সা'দ ইবনে মুআজ (রাঃ)-এর মৃত্যুতে আল্লাহর আরশ কেঁপে উঠেছিল।", lessons: ["আল্লাহর জন্য উৎসর্গিত জীবন দুনিয়ার বাইরেও সম্মানিত হয়।"] },
    links: h(3803), bib: B("Sahih al-Bukhari 3803 (Jabir)") },

  { slug: "abu-jandal-at-hudaybiyyah", period: "treaties", date: "Dhul-Qa'dah, 6 AH", certainty: "established", location: "Al-Hudaybiyyah", people: ["Abu Jandal (RA)", "Suhayl ibn 'Amr", "'Umar (RA)"], themes: ["sabr", "tawakkul", "leadership"],
    en: { title: "Abu Jandal in chains, and a hard patience", summary: "Al-Miswar and Marwan narrate at length in Sahih al-Bukhari the Treaty of Hudaybiyyah: the she-camel kneeling, the hard terms, Abu Jandal arriving in chains and being returned, the Companions' grief — and how what looked like a loss became an open victory (48:1).", lessons: ["What feels like defeat can be the door to victory.", "Keeping one's word, even when it hurts, is part of faith."] },
    bn: { title: "শিকলবন্দী আবু জান্দাল ও কঠিন ধৈর্য", summary: "সহিহ বুখারিতে মিসওয়ার ও মারওয়ান বিস্তারিত বর্ণনা করেন হুদায়বিয়ার সন্ধি: উটনীর বসে পড়া, কঠিন শর্ত, শিকলবন্দী আবু জান্দালের আগমন ও ফেরত পাঠানো, সাহাবিদের দুঃখ — আর পরাজয়ের মতো দেখতে বিষয়টি কীভাবে সুস্পষ্ট বিজয় হলো (৪৮:১)।", lessons: ["যা পরাজয় মনে হয় তা বিজয়ের দরজা হতে পারে।", "কষ্ট হলেও কথা রাখা ঈমানের অংশ।"] },
    links: [...q(48, 1), ...h(2731)], bib: B("Sahih al-Bukhari 2731 (Al-Miswar ibn Makhrama and Marwan)") },

  { slug: "bilals-footsteps-in-paradise", period: "character", date: "Madinan period", certainty: "unknown", location: "Madinah", people: ["Bilal (RA)", "Abu Huraira (RA)"], themes: ["salah", "akhirah"],
    en: { title: "Bilal's footsteps in Paradise", summary: "Abu Huraira (RA) narrates in Sahih al-Bukhari that the Prophet ﷺ told Bilal he had heard his footsteps ahead of him in Paradise, and asked what he did; Bilal said he prayed after every ablution.", lessons: ["A small deed done consistently can carry you far.", "Hidden worship is known to Allah."] },
    bn: { title: "জান্নাতে বিলালের পদধ্বনি", summary: "সহিহ বুখারিতে আবু হুরায়রা (রাঃ) বর্ণনা করেন, নবী ﷺ বিলালকে বললেন তিনি জান্নাতে তাঁর সামনে বিলালের পদধ্বনি শুনেছেন, আর জিজ্ঞেস করলেন তিনি কী আমল করেন; বিলাল বললেন, প্রতিবার অজুর পর তিনি নামাজ পড়েন।", lessons: ["নিয়মিত ছোট আমল অনেক দূর নিয়ে যায়।", "গোপন ইবাদত আল্লাহ জানেন।"] },
    links: h(1149), bib: B("Sahih al-Bukhari 1149 (Abu Huraira)") },

  { slug: "he-wept-at-the-quran", period: "character", date: "Madinan period", certainty: "unknown", location: "Madinah", people: ["'Abdullah ibn Mas'ud (RA)"], themes: ["salah", "akhirah", "sadness"],
    en: { title: "\"Enough\" — and his eyes were full of tears", summary: "'Abdullah ibn Mas'ud (RA) narrates in Sahih al-Bukhari that the Prophet ﷺ asked him to recite the Qur'an to him; when he reached 4:41 — \"How will it be when We bring from every nation a witness, and bring you as a witness over these?\" — the Prophet ﷺ said \"Enough\", and his eyes were shedding tears.", lessons: ["He ﷺ loved listening to the Qur'an from others.", "Let the Qur'an reach the heart, not only the tongue."] },
    bn: { title: "\"যথেষ্ট\" — তাঁর চোখ তখন অশ্রুসিক্ত", summary: "সহিহ বুখারিতে আব্দুল্লাহ ইবনে মাসউদ (রাঃ) বর্ণনা করেন, নবী ﷺ তাঁকে কুরআন তিলাওয়াত করে শোনাতে বলেন; তিনি যখন ৪:৪১ — \"যখন আমি প্রত্যেক উম্মত থেকে একজন সাক্ষী আনব এবং তোমাকে এদের উপর সাক্ষী করব, তখন কী অবস্থা হবে?\" — পর্যন্ত পৌঁছালেন, নবী ﷺ বললেন \"যথেষ্ট\", আর তাঁর চোখ দিয়ে অশ্রু ঝরছিল।", lessons: ["অন্যের মুখে কুরআন শুনতে তিনি ﷺ ভালোবাসতেন।", "কুরআন যেন শুধু জিহ্বায় নয়, হৃদয়ে পৌঁছায়।"] },
    links: [...q(4, 41), ...h(5050)], bib: B("Sahih al-Bukhari 5050 ('Abdullah ibn Mas'ud)") },

  { slug: "his-grandchild-dying", period: "character", date: "Madinan period", certainty: "unknown", location: "Madinah", people: ["Usama ibn Zayd (RA)", "Sa'd ibn 'Ubada (RA)"], themes: ["grief", "parenting", "sabr"],
    en: { title: "\"This is mercy which Allah has placed in hearts\"", summary: "Usama ibn Zayd (RA) narrates in Sahih al-Bukhari that the Prophet ﷺ went to his daughter's dying child; holding the child, his eyes overflowed, and when Sa'd asked about it he said it is mercy that Allah places in the hearts of His servants.", lessons: ["Tears for a loved one are mercy, not complaint.", "Allah is merciful to those who are merciful."] },
    bn: { title: "\"এটা দয়া, যা আল্লাহ বান্দাদের অন্তরে রেখেছেন\"", summary: "সহিহ বুখারিতে উসামা ইবনে যায়েদ (রাঃ) বর্ণনা করেন, মৃত্যুপথযাত্রী নাতির কাছে নবী ﷺ গেলেন; শিশুটিকে কোলে নিয়ে তাঁর চোখ অশ্রুতে ভরে গেল, সা'দ জিজ্ঞেস করলে তিনি বললেন: এটা দয়া, যা আল্লাহ তাঁর বান্দাদের অন্তরে রেখেছেন।", lessons: ["প্রিয়জনের জন্য চোখের পানি দয়া, অভিযোগ নয়।", "যারা দয়া করে, আল্লাহ তাদের প্রতি দয়া করেন।"] },
    links: h(1284), bib: B("Sahih al-Bukhari 1284 (Usama ibn Zayd)") },

  { slug: "abu-bakr-leads-the-prayer", period: "final-days", date: "Rabi' al-Awwal, 11 AH", certainty: "established", location: "The Prophet's Mosque", people: ["Abu Bakr (RA)", "Aisha (RA)"], themes: ["salah", "leadership", "death-awareness"],
    en: { title: "\"Tell Abu Bakr to lead the people in prayer\"", summary: "Aisha (RA) narrates in Sahih al-Bukhari that during his final illness the Prophet ﷺ insisted that Abu Bakr (RA) lead the prayer, and how he came out once, supported between two men, to join it.", lessons: ["Even in illness his heart was with the prayer.", "Prepare others to carry the trust after you."] },
    bn: { title: "\"আবু বকরকে বলো লোকদের নামাজ পড়াতে\"", summary: "সহিহ বুখারিতে আয়েশা (রাঃ) বর্ণনা করেন, শেষ অসুস্থতায় নবী ﷺ জোর দিয়ে বললেন আবু বকর (রাঃ) যেন নামাজ পড়ান, আর একবার তিনি দুজনের কাঁধে ভর দিয়ে নামাজে শরিক হতে বের হন।", lessons: ["অসুস্থতাতেও তাঁর হৃদয় নামাজের সাথে ছিল।", "আপনার পরে আমানত বহনের জন্য অন্যদের প্রস্তুত করুন।"] },
    links: h(664), bib: B("Sahih al-Bukhari 664 (Aisha)") },

  { slug: "fatimas-tears-and-smile", period: "final-days", date: "Rabi' al-Awwal, 11 AH", certainty: "established", location: "Madinah", people: ["Fatima (RA)", "Aisha (RA)"], themes: ["grief", "death-awareness", "akhirah", "family-conflict"],
    en: { title: "Fatima's tears, then her smile", summary: "Aisha (RA) narrates in Sahih al-Bukhari that in his last days the Prophet ﷺ whispered to Fatima (RA) and she wept, then whispered again and she smiled; after his death Fatima explained he had told her of his approaching death, and that she would be the first of his family to follow him.", lessons: ["Close to sadness, Allah places hope.", "Being reunited with those we love is a real consolation."] },
    bn: { title: "ফাতিমার অশ্রু, তারপর হাসি", summary: "সহিহ বুখারিতে আয়েশা (রাঃ) বর্ণনা করেন, শেষ দিনগুলোতে নবী ﷺ ফাতিমা (রাঃ)-কে কানে কানে কিছু বললেন, তিনি কাঁদলেন; আবার বললেন, তিনি হাসলেন। তাঁর ইন্তেকালের পর ফাতিমা জানালেন — তিনি তাঁকে নিজের আসন্ন মৃত্যুর কথা বলেছিলেন, আর বলেছিলেন পরিবারের মধ্যে ফাতিমাই সবার আগে তাঁর সাথে মিলিত হবেন।", lessons: ["দুঃখের খুব কাছেই আল্লাহ আশা রেখে দেন।", "প্রিয়জনদের সাথে আবার মিলিত হওয়া সত্যিকারের সান্ত্বনা।"] },
    links: h(3623), bib: B("Sahih al-Bukhari 3623 (Aisha)") },
];
