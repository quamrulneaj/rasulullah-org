/** Seed taxonomy, candidate mappings, editorial cards, demo Seerah and crisis resources. Idempotent. */
import { eq, inArray, sql } from "drizzle-orm";
import { createDb, databaseUrl } from "../src/server/db/client";
import * as s from "../src/server/db/schema";
import { TOPICS } from "./seed/topics";
import { TOPIC_EVIDENCE } from "./seed/topic-evidence";
import { CARDS, PERIODS, CRISIS } from "./seed/editorial";
import { TIMELINE as TIMELINE_V1 } from "./seed/seerah-timeline";
import { TIMELINE_V2, PERIOD_V2 } from "./seed/seerah-timeline-v2";
import { TIMELINE_V3 } from "./seed/seerah-timeline-v3";
const TIMELINE = [...TIMELINE_V1, ...TIMELINE_V2, ...TIMELINE_V3];

const { db, pool } = createDb(databaseUrl(true), { max: 4 });

// Topics
const isAscii = (w: string) => /^[\x00-\x7F]+$/.test(w);
for (const t of TOPICS) {
  const [row] = await db.insert(s.topics).values({ slug: t.slug, kind: t.kind, sensitivity: t.sensitivity ?? "normal" })
    .onConflictDoUpdate({ target: s.topics.slug, set: { kind: t.kind, sensitivity: t.sensitivity ?? "normal" } }).returning({ id: s.topics.id });
  await db.insert(s.topicTranslations).values([
    { topicId: row!.id, locale: "en", name: t.en, description: t.descEn, lexicon: t.lex.filter(isAscii) },
    { topicId: row!.id, locale: "bn", name: t.bn, description: t.descBn, lexicon: t.lex.filter((w) => !isAscii(w)) },
  ]).onConflictDoUpdate({
    target: [s.topicTranslations.topicId, s.topicTranslations.locale],
    set: { name: sql`excluded.name`, description: sql`excluded.description`, lexicon: sql`excluded.lexicon` },
  });
}
const topicRows = await db.select().from(s.topics);
const topicId = new Map(topicRows.map((t) => [t.slug, t.id]));
console.log(`✓ ${topicRows.length} topics`);

// Topic → evidence candidates
const allRefs = [...new Set(Object.values(TOPIC_EVIDENCE).flat().map((p) => p[0]))];
const evRows = await db.select({ id: s.evidence.id, ref: s.evidence.canonicalRef }).from(s.evidence).where(inArray(s.evidence.canonicalRef, allRefs));
const evId = new Map(evRows.map((e) => [e.ref, e.id]));
const missing = allRefs.filter((r) => !evId.has(r));
if (missing.length) console.warn("! missing evidence (run data:ingest):", missing.join(", "));
let mapped = 0;
for (const [slug, picks] of Object.entries(TOPIC_EVIDENCE)) {
  const tid = topicId.get(slug);
  if (!tid) { console.warn("! unknown topic", slug); continue; }
  for (const [i, [ref, section, note]] of picks.entries()) {
    const eid = evId.get(ref);
    if (!eid) continue;
    await db.insert(s.topicEvidence).values({ topicId: tid, evidenceId: eid, section, weight: 1 - i * 0.05, contextNote: note ?? null, assignedBy: "seed:editor", reviewStatus: "pending_review" }).onConflictDoNothing();
    mapped++;
  }
}
console.log(`✓ ${mapped} candidate topic–evidence mappings (pending_review)`);

// Editorial cards
const existingCards = await db.select({ en: s.editorialCards.textEn }).from(s.editorialCards);
const have = new Set(existingCards.map((c) => c.en));
const newCards = CARDS.filter((c) => !have.has(c.en)).map((c) => ({ kind: c.kind, topicId: c.topic ? topicId.get(c.topic) ?? null : null, textEn: c.en, textBn: c.bn, reviewStatus: "pending_review" as const }));
if (newCards.length) await db.insert(s.editorialCards).values(newCards);
console.log(`✓ ${CARDS.length} editorial cards`);

// Seerah
for (const [i, p] of [...PERIODS, PERIOD_V2].entries()) await db.insert(s.seerahPeriods).values({ slug: p.slug, order: i + 1, nameEn: p.en, nameBn: p.bn }).onConflictDoNothing();
const periodRows = await db.select().from(s.seerahPeriods);
const periodId = new Map(periodRows.map((p) => [p.slug, p.id]));
const [lic] = await db.select().from(s.licenses).where(eq(s.licenses.name, "Rasulullah.org editorial"));
const licId = lic?.id ?? (await db.insert(s.licenses).values({ name: "Rasulullah.org editorial", type: "proprietary_internal", attributionText: "Rasulullah.org editorial team", allowsCache: true, allowsIndex: true, allowsEmbed: true, status: "verified" }).returning())[0]!.id;
const [src] = await db.insert(s.sources).values({ key: "editorial:seerah", kind: "seerah_work", name: "Rasulullah.org Seerah (editorial)", language: "en", licenseId: licId, trustLevel: "C" })
  .onConflictDoUpdate({ target: s.sources.key, set: { name: "Rasulullah.org Seerah (editorial)" } }).returning({ id: s.sources.id });
let seerahWritten = 0;
for (const [i, ev] of TIMELINE.entries()) {
  // Seed-owned rows (demo or seed:editor, not yet approved) are refreshed; rows an editor has taken over are left alone.
  const [existing] = await db.select().from(s.seerahEvents).where(eq(s.seerahEvents.slug, ev.slug));
  if (existing) {
    const seedOwned = existing.authorId === "seed:demo" || existing.authorId === "seed:editor";
    if (!seedOwned || existing.reviewStatus === "approved") continue;
    await db.delete(s.seerahEvents).where(eq(s.seerahEvents.id, existing.id));
  }
  const [e] = await db.insert(s.evidence).values({ kind: "seerah_event", canonicalRef: `seerah:${ev.slug}`, sourceId: src!.id, trustLevel: "C", reviewStatus: "pending_review", isDemo: false })
    .onConflictDoUpdate({ target: s.evidence.canonicalRef, set: { isDemo: false, reviewStatus: "pending_review" } }).returning({ id: s.evidence.id });
  const [row] = await db.insert(s.seerahEvents).values({
    slug: ev.slug, evidenceId: e!.id, periodId: periodId.get(ev.period)!, order: i + 1, approximateDate: ev.date,
    dateCertainty: ev.certainty, location: ev.location, people: ev.people, themes: ev.themes,
    reviewStatus: "pending_review", isDemo: false, authorId: "seed:editor",
  }).returning({ id: s.seerahEvents.id });
  await db.insert(s.seerahEventTranslations).values([
    { eventId: row!.id, locale: "en", title: ev.en.title, summary: ev.en.summary, lessons: ev.en.lessons },
    { eventId: row!.id, locale: "bn", title: ev.bn.title, summary: ev.bn.summary, lessons: ev.bn.lessons },
  ]);
  let missing = 0;
  for (const [ref, rel] of ev.links) {
    const [x] = await db.select({ id: s.evidence.id }).from(s.evidence).where(eq(s.evidence.canonicalRef, ref));
    if (x) await db.insert(s.seerahEventLinks).values({ eventId: row!.id, evidenceId: x.id, relation: rel }).onConflictDoNothing();
    else missing++;
  }
  if (missing) console.warn(`! ${ev.slug}: ${missing} linked source(s) not found — run data:ingest first`);
  for (const [citation, primary] of ev.bib) await db.insert(s.bibliographyEntries).values({ eventId: row!.id, citation, isPrimarySource: primary });
  seerahWritten++;
}
console.log(`✓ Seerah timeline: ${seerahWritten}/${TIMELINE.length} events written (pending_review)`);

// Crisis resources
const haveCrisis = await db.select().from(s.crisisResources);
if (!haveCrisis.length) await db.insert(s.crisisResources).values(CRISIS);
console.log(`✓ crisis resources (unverified — verify in /admin/crisis)`);

await pool.end();
